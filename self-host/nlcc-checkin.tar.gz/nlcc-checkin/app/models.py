"""All SQLAlchemy models: staff, families, children, classes, roster, attendance, settings, audit."""
import uuid
from datetime import date, datetime, timezone

from sqlalchemy import Boolean, Date, DateTime, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base


def _uuid() -> str:
    return str(uuid.uuid4())


def _now() -> datetime:
    return datetime.now(timezone.utc)


class Staff(Base):
    """Admins and teachers. Teachers may exist without a login (roster/reminders only)."""
    __tablename__ = "staff"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    name: Mapped[str] = mapped_column(String(120))
    email: Mapped[str] = mapped_column(String(254), unique=True, index=True)
    phone: Mapped[str] = mapped_column(String(32), default="")
    role: Mapped[str] = mapped_column(String(16), default="teacher")  # admin | teacher
    password_hash: Mapped[str | None] = mapped_column(String(100), nullable=True)
    can_login: Mapped[bool] = mapped_column(Boolean, default=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    remind_by_email: Mapped[bool] = mapped_column(Boolean, default=True)
    failed_logins: Mapped[int] = mapped_column(Integer, default=0)
    locked_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    session_version: Mapped[int] = mapped_column(Integer, default=1)
    mfa_secret: Mapped[str | None] = mapped_column(String(64), nullable=True)
    mfa_enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    mfa_backup_codes: Mapped[str] = mapped_column(Text, default="")  # newline-separated bcrypt hashes
    theme: Mapped[str] = mapped_column(String(8), default="dark")
    font_size: Mapped[str] = mapped_column(String(8), default="default")
    last_login: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)

    @property
    def is_admin(self) -> bool:
        return self.role == "admin"


class ClassGroup(Base):
    __tablename__ = "class_groups"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    name: Mapped[str] = mapped_column(String(80))
    room: Mapped[str] = mapped_column(String(80), default="")
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)


class Family(Base):
    __tablename__ = "families"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    name: Mapped[str] = mapped_column(String(120))
    authorized_pickups: Mapped[str] = mapped_column(Text, default="")  # one name per line
    notes: Mapped[str] = mapped_column(Text, default="")  # staff-only
    link_version: Mapped[int] = mapped_column(Integer, default=1)  # bump to revoke the family link
    is_guest: Mapped[bool] = mapped_column(Boolean, default=False)  # registered at the check-in station
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    theme: Mapped[str] = mapped_column(String(8), default="dark")
    font_size: Mapped[str] = mapped_column(String(8), default="default")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)

    guardians: Mapped[list["Guardian"]] = relationship(back_populates="family", cascade="all, delete-orphan",
                                                       order_by="Guardian.created_at")
    children: Mapped[list["Child"]] = relationship(back_populates="family", cascade="all, delete-orphan",
                                                   order_by="Child.first_name")

    def pickup_names(self) -> list[str]:
        names = [g.name for g in self.guardians]
        for line in (self.authorized_pickups or "").splitlines():
            line = line.strip()
            if line and line not in names:
                names.append(line)
        return names


class Guardian(Base):
    __tablename__ = "guardians"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    family_id: Mapped[str] = mapped_column(ForeignKey("families.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(120))
    email: Mapped[str] = mapped_column(String(254), default="")
    phone: Mapped[str] = mapped_column(String(32), default="")
    notify_email: Mapped[bool] = mapped_column(Boolean, default=True)
    notify_sms: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    family: Mapped[Family] = relationship(back_populates="guardians")


class Child(Base):
    __tablename__ = "children"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    family_id: Mapped[str] = mapped_column(ForeignKey("families.id", ondelete="CASCADE"), index=True)
    first_name: Mapped[str] = mapped_column(String(80))
    last_name: Mapped[str] = mapped_column(String(80), default="")
    class_id: Mapped[str | None] = mapped_column(ForeignKey("class_groups.id", ondelete="SET NULL"),
                                                 index=True, nullable=True)
    care_notes: Mapped[str] = mapped_column(Text, default="")  # allergies etc., shown to teachers
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    family: Mapped[Family] = relationship(back_populates="children")
    class_group: Mapped[ClassGroup | None] = relationship()

    @property
    def full_name(self) -> str:
        return f"{self.first_name} {self.last_name}".strip()


class RosterEntry(Base):
    __tablename__ = "roster_entries"
    __table_args__ = (UniqueConstraint("service_date", "staff_id", name="uq_roster_date_staff"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    service_date: Mapped[date] = mapped_column(Date, index=True)
    staff_id: Mapped[str] = mapped_column(ForeignKey("staff.id", ondelete="CASCADE"), index=True)
    class_id: Mapped[str | None] = mapped_column(ForeignKey("class_groups.id", ondelete="SET NULL"),
                                                 index=True, nullable=True)
    note: Mapped[str] = mapped_column(Text, default="")  # lesson or topic, included in reminders
    reminded_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    staff: Mapped[Staff] = relationship()
    class_group: Mapped[ClassGroup | None] = relationship()


class Attendance(Base):
    __tablename__ = "attendance"
    __table_args__ = (UniqueConstraint("child_id", "service_date", name="uq_attendance_child_date"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    child_id: Mapped[str | None] = mapped_column(ForeignKey("children.id", ondelete="SET NULL"), index=True,
                                                 nullable=True)  # NULL once the child is deleted; history stays
    child_name: Mapped[str] = mapped_column(String(160), default="")  # snapshot at check-in
    service_date: Mapped[date] = mapped_column(Date, index=True)
    class_name: Mapped[str] = mapped_column(String(80), default="")  # snapshot at check-in
    checked_in_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    checked_in_by: Mapped[str] = mapped_column(String(160), default="")
    pickup_requested_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    pickup_person: Mapped[str] = mapped_column(String(120), default="")
    pickup_code: Mapped[str] = mapped_column(String(8), default="")
    checked_out_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    checked_out_by: Mapped[str] = mapped_column(String(160), default="")  # who recorded it
    released_by: Mapped[str] = mapped_column(String(120), default="")  # teacher who released
    code_verified: Mapped[bool] = mapped_column(Boolean, default=False)
    child: Mapped[Child | None] = relationship()

    @property
    def display_name(self) -> str:
        return self.child.full_name if self.child else (self.child_name or "Deleted child")

    @property
    def status(self) -> str:
        if self.checked_out_at:
            return "out"
        if self.pickup_requested_at:
            return "pickup"
        return "in"


class AppSettings(Base):
    """Single-row table (id=1) edited from Admin > Settings."""
    __tablename__ = "app_settings"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, default=1)
    church_name: Mapped[str] = mapped_column(String(120), default="Our Church")
    program_name: Mapped[str] = mapped_column(String(120), default="Sunday School")
    address: Mapped[str] = mapped_column(Text, default="")
    contact_phone: Mapped[str] = mapped_column(String(40), default="")
    brand_color: Mapped[str] = mapped_column(String(7), default="#3D5AFE")
    logo_file: Mapped[str] = mapped_column(String(80), default="")
    public_base_url: Mapped[str] = mapped_column(String(255), default="")
    timezone: Mapped[str] = mapped_column(String(64), default="America/Toronto")

    checkin_opens: Mapped[str] = mapped_column(String(5), default="09:00")
    checkin_closes: Mapped[str] = mapped_column(String(5), default="13:30")
    open_any_day: Mapped[bool] = mapped_column(Boolean, default=False)
    require_teacher_release: Mapped[bool] = mapped_column(Boolean, default=True)

    checkin_reminder_on: Mapped[bool] = mapped_column(Boolean, default=True)
    checkin_reminder_time: Mapped[str] = mapped_column(String(5), default="10:55")
    checkout_reminder_on: Mapped[bool] = mapped_column(Boolean, default=True)
    checkout_reminder_time: Mapped[str] = mapped_column(String(5), default="12:00")
    weekly_report_on: Mapped[bool] = mapped_column(Boolean, default=True)
    weekly_report_time: Mapped[str] = mapped_column(String(5), default="12:30")
    monthly_report_on: Mapped[bool] = mapped_column(Boolean, default=True)
    monthly_report_time: Mapped[str] = mapped_column(String(5), default="08:00")
    teacher_reminder_on: Mapped[bool] = mapped_column(Boolean, default=True)
    teacher_reminder_time: Mapped[str] = mapped_column(String(5), default="18:00")  # Saturday
    sms_enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    report_recipients: Mapped[str] = mapped_column(Text, default="")  # comma/newline separated
    min_adults_per_class: Mapped[int] = mapped_column(Integer, default=2)
    email_teachers_on_checkin: Mapped[bool] = mapped_column(Boolean, default=True)
    kiosk_token: Mapped[str] = mapped_column(String(64), default="")
    kiosk_guests_on: Mapped[bool] = mapped_column(Boolean, default=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now, onupdate=_now)


class ServiceEvent(Base):
    """A dated entry on the calendar: a special event (VBS, Christmas program) or a cancelled Sunday."""
    __tablename__ = "service_events"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    event_date: Mapped[date] = mapped_column(Date, unique=True, index=True)
    name: Mapped[str] = mapped_column(String(120), default="")
    start_time: Mapped[str] = mapped_column(String(5), default="10:00")
    end_time: Mapped[str] = mapped_column(String(5), default="12:00")
    cancelled: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)


class JobRun(Base):
    """Makes scheduled jobs idempotent: one row per job per local date."""
    __tablename__ = "job_runs"
    __table_args__ = (UniqueConstraint("job", "run_key", name="uq_job_run"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    job: Mapped[str] = mapped_column(String(40))
    run_key: Mapped[str] = mapped_column(String(20))
    result: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)


class AuditLog(Base):
    __tablename__ = "audit_log"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now, index=True)
    actor: Mapped[str] = mapped_column(String(254), default="system")
    action: Mapped[str] = mapped_column(String(40), index=True)
    target_type: Mapped[str] = mapped_column(String(40), default="")
    target_id: Mapped[str] = mapped_column(String(36), default="")
    detail: Mapped[str] = mapped_column(Text, default="")
    ip_address: Mapped[str] = mapped_column(String(64), default="")
