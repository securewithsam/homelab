"""Weekly and monthly attendance PDFs (ReportLab). Built for the child-safety record."""
import calendar
import io
import os
from collections import defaultdict
from datetime import date, datetime, timezone

from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import Image, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.attendance import events_between
from app.config import UPLOAD_DIR
from app.models import AppSettings, Attendance, RosterEntry
from app.timeutil import fmt_datetime, fmt_time, now_local

_styles = getSampleStyleSheet()
H1 = ParagraphStyle("h1", parent=_styles["Heading1"], fontSize=17, spaceAfter=2)
H2 = ParagraphStyle("h2", parent=_styles["Heading2"], fontSize=12.5, spaceBefore=12, spaceAfter=6)
BODY = ParagraphStyle("b", parent=_styles["BodyText"], fontSize=9.5, leading=12)
SMALL = ParagraphStyle("s", parent=BODY, fontSize=8, textColor=colors.HexColor("#555555"))
CELL = ParagraphStyle("c", parent=BODY, fontSize=8.5, leading=10.5)
WARN = ParagraphStyle("w", parent=BODY, textColor=colors.HexColor("#A61B1B"))


def _brand(s: AppSettings) -> colors.Color:
    try:
        return colors.HexColor(s.brand_color)
    except ValueError:
        return colors.HexColor("#3D5AFE")


def _ink(c: colors.Color) -> colors.Color:
    """Black or white header text, whichever reads better on the brand color."""
    from app.templating import on_color
    return colors.HexColor(on_color("#%02X%02X%02X" % (int(c.red * 255), int(c.green * 255), int(c.blue * 255))))


def _p(text: str, style=CELL) -> Paragraph:
    from xml.sax.saxutils import escape
    return Paragraph(escape(text or ""), style)


def _header(s: AppSettings, title: str, subtitle: str) -> list:
    parts = []
    logo_path = os.path.join(UPLOAD_DIR, s.logo_file) if s.logo_file else ""
    title_block = [Paragraph(_esc(s.church_name), H1), Paragraph(_esc(title), BODY),
                   Paragraph(_esc(subtitle), SMALL)]
    if logo_path and os.path.isfile(logo_path):
        img = Image(logo_path)
        ratio = img.imageHeight / float(img.imageWidth or 1)
        img.drawWidth, img.drawHeight = 0.9 * inch, 0.9 * inch * ratio
        t = Table([[img, title_block]], colWidths=[1.05 * inch, None])
    else:
        t = Table([[title_block]])
    t.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("LEFTPADDING", (0, 0), (-1, -1), 0)]))
    parts.append(t)
    bar = Table([[""]], colWidths=[7.5 * inch], rowHeights=[3])
    bar.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), _brand(s))]))
    parts += [Spacer(1, 6), bar, Spacer(1, 8)]
    return parts


def _esc(t: str) -> str:
    from xml.sax.saxutils import escape
    return escape(t or "")


def _table(rows: list[list], widths: list[float], brand: colors.Color, flag_rows: list[int] | None = None) -> Table:
    t = Table(rows, colWidths=widths, repeatRows=1)
    style = [
        ("BACKGROUND", (0, 0), (-1, 0), brand), ("TEXTCOLOR", (0, 0), (-1, 0), _ink(brand)),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"), ("FONTSIZE", (0, 0), (-1, -1), 8.5),
        ("VALIGN", (0, 0), (-1, -1), "TOP"), ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#C9CED8")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F3F5F9")]),
    ]
    for r in flag_rows or []:
        style.append(("BACKGROUND", (0, r), (-1, r), colors.HexColor("#FDE8E8")))
    t.setStyle(TableStyle(style))
    return t


def _footer(s: AppSettings):
    def draw(canvas, doc):
        canvas.saveState()
        canvas.setFont("Helvetica", 7.5)
        canvas.setFillColor(colors.HexColor("#666666"))
        canvas.drawString(0.5 * inch, 0.4 * inch,
                          f"Confidential child-safety record. {s.church_name} {s.program_name}.")
        canvas.drawRightString(8.0 * inch, 0.4 * inch, f"Page {doc.page}")
        canvas.restoreState()
    return draw


def _build(story: list, s: AppSettings) -> bytes:
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=letter, leftMargin=0.5 * inch, rightMargin=0.5 * inch,
                            topMargin=0.5 * inch, bottomMargin=0.65 * inch,
                            title=f"{s.church_name} attendance", author=s.church_name)
    doc.build(story, onFirstPage=_footer(s), onLaterPages=_footer(s))
    return buf.getvalue()


async def _records(db: AsyncSession, start: date, end: date) -> list[Attendance]:
    rows = await db.execute(
        select(Attendance).options(selectinload(Attendance.child))
        .where(Attendance.service_date >= start, Attendance.service_date <= end)
        .order_by(Attendance.service_date, Attendance.class_name, Attendance.checked_in_at))
    return list(rows.scalars())


async def _roster(db: AsyncSession, start: date, end: date) -> list[RosterEntry]:
    rows = await db.execute(
        select(RosterEntry).options(selectinload(RosterEntry.staff), selectinload(RosterEntry.class_group))
        .where(RosterEntry.service_date >= start, RosterEntry.service_date <= end))
    return list(rows.scalars())


def _coverage(roster: list[RosterEntry], records: list[Attendance], s: AppSettings) -> tuple[list[list], list[int]]:
    by_class: dict[str, list[str]] = defaultdict(list)
    for r in roster:
        by_class[r.class_group.name if r.class_group else "Any class"].append(r.staff.name)
    kids = defaultdict(int)
    for a in records:
        kids[a.class_name] += 1
    rows = [["Class", "Children", "Adults on roster", "Status"]]
    flags = []
    floating = len(by_class.get("Any class", []))
    for cls in sorted(set(kids) | {k for k in by_class if k != "Any class"}):
        adults = by_class.get(cls, [])
        ok = len(adults) >= s.min_adults_per_class or (kids[cls] == 0)
        status = "OK" if ok else f"Below {s.min_adults_per_class}-adult rule"
        if not ok and floating:
            status += " (floating helpers listed)"
        rows.append([_p(cls), str(kids[cls]), _p(", ".join(adults) or "None"), _p(status)])
        if not ok:
            flags.append(len(rows) - 1)
    if floating:
        rows.append([_p("Any class (floating)"), "", _p(", ".join(by_class["Any class"])), ""])
    return rows, flags


async def build_weekly(db: AsyncSession, s: AppSettings, d: date, name: str = "") -> bytes:
    tzn = s.timezone
    records = await _records(db, d, d)
    roster = await _roster(db, d, d)
    brand = _brand(s)
    story = _header(s, f"{name or s.program_name} attendance, {d.strftime('%A, %B %-d, %Y')}",
                    f"Generated {fmt_datetime(datetime.now(timezone.utc), tzn)} ({tzn})")

    not_out = [a for a in records if not a.checked_out_at]
    unverified = [a for a in records if a.checked_out_at and s.require_teacher_release and not a.code_verified]
    summary = [["Checked in", "Checked out", "Not checked out", "Released without code"],
               [str(len(records)), str(len(records) - len(not_out)), str(len(not_out)), str(len(unverified))]]
    t = _table(summary, [1.875 * inch] * 4, brand)
    if not_out or unverified:
        t.setStyle(TableStyle([("TEXTCOLOR", (2, 1), (3, 1), colors.HexColor("#A61B1B")),
                               ("FONTNAME", (2, 1), (3, 1), "Helvetica-Bold")]))
    story += [t]

    if not_out:
        story += [Paragraph("Needs follow-up: not checked out", H2)]
        for a in not_out:
            story.append(Paragraph(_esc(f"{a.display_name} ({a.class_name}), checked in "
                                        f"{fmt_time(a.checked_in_at, tzn)} by {a.checked_in_by}"), WARN))

    cov_rows, cov_flags = _coverage(roster, records, s)
    story += [Paragraph("Supervision", H2),
              _table(cov_rows, [1.9 * inch, 0.9 * inch, 3.1 * inch, 1.6 * inch], brand, cov_flags)]

    by_class: dict[str, list[Attendance]] = defaultdict(list)
    for a in records:
        by_class[a.class_name].append(a)
    if not records:
        story += [Spacer(1, 10), Paragraph("No children were checked in on this date.", BODY)]
    for cls, items in by_class.items():
        rows = [["Child", "In", "Checked in by", "Out", "Picked up by", "Released by", "Code"]]
        flags = []
        for a in items:
            rows.append([_p(a.display_name), fmt_time(a.checked_in_at, tzn), _p(a.checked_in_by),
                         fmt_time(a.checked_out_at, tzn) or "—", _p(a.pickup_person or "—"),
                         _p(a.released_by or ("Parent" if a.checked_out_at else "—")),
                         "Yes" if a.code_verified else ("—" if not a.checked_out_at else "No")])
            if not a.checked_out_at:
                flags.append(len(rows) - 1)
        story += [Paragraph(f"{_esc(cls)} ({len(items)})", H2),
                  _table(rows, [1.5 * inch, 0.65 * inch, 1.45 * inch, 0.65 * inch, 1.25 * inch, 1.3 * inch,
                                0.7 * inch], brand, flags)]
    return _build(story, s)


def sundays_in(year: int, month: int) -> list[date]:
    return [date(year, month, day) for day in range(1, calendar.monthrange(year, month)[1] + 1)
            if date(year, month, day).weekday() == 6]


async def build_monthly(db: AsyncSession, s: AppSettings, year: int, month: int) -> bytes:
    tzn = s.timezone
    start, end = date(year, month, 1), date(year, month, calendar.monthrange(year, month)[1])
    records = await _records(db, start, end)
    roster = await _roster(db, start, end)
    brand = _brand(s)
    story = _header(s, f"{s.program_name} monthly report, {start.strftime('%B %Y')}",
                    f"Generated {fmt_datetime(datetime.now(timezone.utc), tzn)} ({tzn})")

    classes = sorted({a.class_name for a in records})
    evs = await events_between(db, start, end)
    planned = {d for d in sundays_in(year, month) if not (evs.get(d) and evs[d].cancelled)}
    planned |= {d for d, e in evs.items() if not e.cancelled}
    sundays = sorted({a.service_date for a in records} | planned)
    rows = [["Date"] + [_p(c, ParagraphStyle("hc", parent=CELL, textColor=_ink(brand))) for c in classes]
            + ["Total", "Not out", "Adults"]]
    flags = []
    for d in sundays:
        day = [a for a in records if a.service_date == d]
        adults = len([r for r in roster if r.service_date == d])
        not_out = len([a for a in day if not a.checked_out_at])
        label = d.strftime("%b %-d") + (f" {evs[d].name}"[:22] if d in evs and evs[d].name else "")
        rows.append([_p(label)] + [str(len([a for a in day if a.class_name == c])) for c in classes]
                    + [str(len(day)), str(not_out), str(adults)])
        if not_out:
            flags.append(len(rows) - 1)
    n = len(classes)
    widths = [1.2 * inch] + [max(0.55, 4.2 / max(n, 1)) * inch] * n + [0.6 * inch, 0.7 * inch, 0.7 * inch]
    story += [Paragraph("Attendance by class day", H2), _table(rows, widths, brand, flags)]

    total_kids = len({a.child_id or a.display_name for a in records})
    story += [Spacer(1, 6), Paragraph(
        f"{len(records)} check-ins across {len({a.service_date for a in records})} service days; "
        f"{total_kids} different children attended.", BODY)]

    exceptions = [a for a in records if not a.checked_out_at or
                  (s.require_teacher_release and a.checked_out_at and not a.code_verified)]
    story += [Paragraph("Exceptions", H2)]
    if exceptions:
        er = [["Date", "Child", "Class", "Issue"]]
        for a in exceptions:
            issue = "Not checked out" if not a.checked_out_at else f"Released without code by {a.released_by or 'parent'}"
            er.append([a.service_date.strftime("%b %-d"), _p(a.display_name), _p(a.class_name), _p(issue)])
        story.append(_table(er, [0.9 * inch, 2.2 * inch, 1.8 * inch, 2.6 * inch], brand, list(range(1, len(er)))))
    else:
        story.append(Paragraph("None. Every child was checked out and released as expected.", BODY))

    counts: dict[str, list] = {}
    for a in records:
        c = counts.setdefault(a.child_id or f"deleted:{a.display_name}", [a.display_name, a.class_name, 0])
        c[2] += 1
    cr = [["Child", "Class", "Sundays attended"]]
    for name, cls, cnt in sorted(counts.values(), key=lambda x: (x[1], x[0])):
        cr.append([_p(name), _p(cls), str(cnt)])
    story += [Paragraph("Attendance by child", H2), _table(cr, [3 * inch, 3 * inch, 1.5 * inch], brand)]
    return _build(story, s)


def report_filename(s: AppSettings, kind: str, label: str) -> str:
    base = "".join(ch for ch in s.program_name if ch.isalnum()) or "SundaySchool"
    return f"{base}-{kind}-{label}.pdf"


def local_now(s: AppSettings) -> datetime:
    return now_local(s.timezone)
