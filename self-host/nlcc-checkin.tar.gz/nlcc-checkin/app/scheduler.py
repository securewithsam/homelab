"""Scheduler process (runs in its own container): fires reminders and reports at the times set in Settings.

Each job runs at most once per local date (job_runs table), and only inside a grace window,
so a restart at 3 PM doesn't send a 10:55 AM reminder.
"""
import asyncio
import logging
from datetime import date, datetime, timedelta

from sqlalchemy.exc import IntegrityError

from app.attendance import service_day
from app.database import async_session, init_db
from app.jobs import (run_and_log, send_checkin_reminders, send_checkout_reminders, send_monthly_report,
                      send_teacher_reminders, send_weekly_report)
from app.models import JobRun
from app.settings_service import get_settings
from app.timeutil import now_local, parse_hhmm

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
logger = logging.getLogger("scheduler")

REMINDER_GRACE = timedelta(minutes=45)
REPORT_GRACE = timedelta(hours=10)


def _due(now: datetime, hhmm: str, grace: timedelta) -> bool:
    t = parse_hhmm(hhmm)
    start = now.replace(hour=t.hour, minute=t.minute, second=0, microsecond=0)
    return start <= now <= start + grace


async def _claim(job: str, key: str) -> bool:
    async with async_session() as db:
        db.add(JobRun(job=job, run_key=key))
        try:
            await db.commit()
            return True
        except IntegrityError:
            return False


async def tick() -> None:
    async with async_session() as db:
        s = await get_settings(db)
        now = now_local(s.timezone)
        key = now.date().isoformat()
        sd = await service_day(db, s, now.date())  # Sunday or calendar event; None if cancelled / no class
        tomorrow = await service_day(db, s, now.date() + timedelta(days=1))

        jobs = []
        if sd and s.checkin_reminder_on and _due(now, sd.checkin_reminder, REMINDER_GRACE):
            jobs.append(("checkin_reminder", lambda: send_checkin_reminders(db, s)))
        if sd and s.checkout_reminder_on and _due(now, sd.checkout_reminder, REMINDER_GRACE):
            jobs.append(("checkout_reminder", lambda: send_checkout_reminders(db, s)))
        if sd and s.weekly_report_on and _due(now, sd.report_time, REPORT_GRACE):
            jobs.append(("weekly_report", lambda: send_weekly_report(db, s, now.date())))
        if tomorrow and s.teacher_reminder_on and _due(now, s.teacher_reminder_time, REMINDER_GRACE):
            jobs.append(("teacher_reminder", lambda: send_teacher_reminders(db, s, now.date() + timedelta(days=1))))
        if now.day == 1 and s.monthly_report_on and _due(now, s.monthly_report_time, REPORT_GRACE):
            prev = date(now.year, now.month, 1) - timedelta(days=1)
            jobs.append(("monthly_report", lambda: send_monthly_report(db, s, prev.year, prev.month)))

        for name, make in jobs:
            if await _claim(name, key):
                await run_and_log(db, "scheduler", f"job.{name}", make())


async def main() -> None:
    await init_db()
    logger.info("Scheduler started")
    while True:
        try:
            await tick()
        except Exception:
            logger.exception("Scheduler tick failed")
        await asyncio.sleep(30)


if __name__ == "__main__":
    asyncio.run(main())
