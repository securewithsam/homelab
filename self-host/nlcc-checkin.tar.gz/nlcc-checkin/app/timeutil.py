"""Timezone helpers. All storage is UTC; display and scheduling use the church's timezone."""
from datetime import date, datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError


def tz(name: str) -> ZoneInfo:
    try:
        return ZoneInfo(name)
    except (ZoneInfoNotFoundError, ValueError):
        return ZoneInfo("America/Toronto")


def now_local(tzname: str) -> datetime:
    return datetime.now(timezone.utc).astimezone(tz(tzname))


def parse_hhmm(value: str, fallback: str = "00:00") -> time:
    try:
        h, m = (value or fallback).split(":")
        return time(int(h), int(m))
    except (ValueError, AttributeError):
        h, m = fallback.split(":")
        return time(int(h), int(m))


def valid_hhmm(value: str) -> bool:
    try:
        h, m = value.split(":")
        return len(value) == 5 and 0 <= int(h) <= 23 and 0 <= int(m) <= 59
    except (ValueError, AttributeError):
        return False


def fmt_time(dt: datetime | None, tzname: str) -> str:
    if not dt:
        return ""
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(tz(tzname)).strftime("%-I:%M %p")


def fmt_datetime(dt: datetime | None, tzname: str) -> str:
    if not dt:
        return ""
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(tz(tzname)).strftime("%b %-d, %Y %-I:%M %p")


def fmt_hhmm(value: str) -> str:
    t = parse_hhmm(value)
    return datetime.combine(date.today(), t).strftime("%-I:%M %p")


def next_sunday(d: date) -> date:
    return d + timedelta(days=(6 - d.weekday()) % 7)


def last_sunday_on_or_before(d: date) -> date:
    return d - timedelta(days=(d.weekday() + 1) % 7)
