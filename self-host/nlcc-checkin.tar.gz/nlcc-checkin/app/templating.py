"""Jinja2 setup and render() helper that injects branding, theme, CSRF and flash messages."""
import re
from fastapi import Request
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from itsdangerous import BadSignature, URLSafeTimedSerializer
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth import csrf_token
from app.config import COOKIE_SECURE, SECRET_KEY
from app.settings_service import get_settings
from app.timeutil import fmt_datetime, fmt_hhmm, fmt_time

templates = Jinja2Templates(directory="app/templates")
HEX = re.compile(r"^#[0-9a-fA-F]{6}$")
_flash_ser = URLSafeTimedSerializer(SECRET_KEY, salt="flash")
FLASH_COOKIE = "nlcc_flash"
FONT_SIZES = {"small": "16px", "default": "18px", "large": "21px", "xl": "24px"}


def on_color(hex_color: str) -> str:
    """Pick black or white text for a brand-colored fill (WCAG relative luminance)."""
    if not HEX.match(hex_color or ""):
        return "#0B1020"
    def ch(i: int) -> float:
        c = int(hex_color[i:i + 2], 16) / 255
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    lum = 0.2126 * ch(1) + 0.7152 * ch(3) + 0.0722 * ch(5)
    # White text whenever it meets WCAG AA (4.5:1); dark text only for very light brand colors.
    return "#FFFFFF" if (1.05 / (lum + 0.05)) >= 4.5 else "#0B1020"


async def render(request: Request, db: AsyncSession, name: str, ctx: dict | None = None,
                 status_code: int = 200, theme: str | None = None, font_size: str | None = None):
    s = await get_settings(db)
    staff = getattr(request.state, "staff", None)
    theme = theme or (staff.theme if staff else request.cookies.get("nlcc_theme", "dark"))
    font_size = font_size or (staff.font_size if staff else request.cookies.get("nlcc_font", "default"))
    flash = {}
    try:
        flash = _flash_ser.loads(request.cookies.get(FLASH_COOKIE, ""), max_age=120)
    except BadSignature:
        pass
    brand = s.brand_color if HEX.match(s.brand_color or "") else "#3D5AFE"
    data = {
        "request": request, "s": s, "me": staff, "csrf": csrf_token(request),
        "theme": theme if theme in ("dark", "light") else "dark",
        "font_px": FONT_SIZES.get(font_size, "18px"), "font_size": font_size,
        "brand": brand, "on_brand": on_color(brand),
        "flash": flash.get("m", ""), "flash_kind": "error" if flash.get("e") else "success",
        "fmt_time": lambda dt: fmt_time(dt, s.timezone),
        "fmt_dt": lambda dt: fmt_datetime(dt, s.timezone),
        "fmt_hhmm": fmt_hhmm,
    }
    data.update(ctx or {})
    resp = templates.TemplateResponse(request, name, data, status_code=status_code)
    if flash:
        resp.delete_cookie(FLASH_COOKIE, path="/")
    return resp


def redirect(url: str, msg: str = "", error: bool = False) -> RedirectResponse:
    """303 redirect with an optional one-time message (signed cookie, never in the URL)."""
    resp = RedirectResponse(url, status_code=303)
    if msg:
        resp.set_cookie(FLASH_COOKIE, _flash_ser.dumps({"m": msg[:300], "e": error}), max_age=120,
                        httponly=True, secure=COOKIE_SECURE, samesite="lax", path="/")
    return resp
