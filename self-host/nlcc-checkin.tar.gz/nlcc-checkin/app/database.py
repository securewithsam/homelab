"""Async SQLAlchemy engine, session factory, declarative Base and init_db()."""
import logging
from collections.abc import AsyncIterator

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase

from app.config import DATABASE_URL

logger = logging.getLogger("database")

_kwargs = {} if DATABASE_URL.startswith("sqlite") else {"pool_size": 10, "max_overflow": 5, "pool_pre_ping": True}
engine = create_async_engine(DATABASE_URL, **_kwargs)
async_session = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)


class Base(DeclarativeBase):
    pass


async def init_db() -> None:
    from app import models  # noqa: F401  (register models)
    try:
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
    except Exception as e:  # another worker/container created them first
        logger.info("init_db skipped: %s", type(e).__name__)
    from app.migrations import migrate
    await migrate(engine)


async def get_db() -> AsyncIterator[AsyncSession]:
    async with async_session() as session:
        yield session
