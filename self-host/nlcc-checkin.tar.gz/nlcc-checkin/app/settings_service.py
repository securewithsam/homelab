"""Load (and lazily create) the single settings row."""
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import DEFAULT_TIMEZONE, PUBLIC_BASE_URL
from app.models import AppSettings


async def get_settings(db: AsyncSession) -> AppSettings:
    s = await db.get(AppSettings, 1)
    if s:
        return s
    s = AppSettings(id=1, timezone=DEFAULT_TIMEZONE, public_base_url=PUBLIC_BASE_URL)
    db.add(s)
    try:
        await db.commit()
    except IntegrityError:
        await db.rollback()
    return await db.get(AppSettings, 1)


def base_url(s: AppSettings) -> str:
    return (s.public_base_url or PUBLIC_BASE_URL or "").rstrip("/")


def report_recipients(s: AppSettings) -> list[str]:
    raw = (s.report_recipients or "").replace("\n", ",").replace(";", ",")
    return [e.strip() for e in raw.split(",") if "@" in e.strip()]
