// Progressive enhancement only: every page works without JavaScript.
(function () {
  "use strict";

  // Mobile menu
  document.querySelectorAll("[data-navtoggle]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var nav = document.getElementById(btn.getAttribute("aria-controls"));
      var open = nav.classList.toggle("open");
      btn.setAttribute("aria-expanded", open ? "true" : "false");
    });
  });

  // Confirm before destructive actions
  document.querySelectorAll("form[data-confirm]").forEach(function (form) {
    form.addEventListener("submit", function (e) {
      if (!window.confirm(form.getAttribute("data-confirm"))) e.preventDefault();
    });
  });

  // Prevent double taps on submit buttons
  document.querySelectorAll("form").forEach(function (form) {
    form.addEventListener("submit", function (e) {
      if (e.defaultPrevented) return;
      var b = form.querySelector("button[type=submit]");
      if (b) { setTimeout(function () { b.disabled = true; b.setAttribute("data-busy", "1"); }, 0); }
    });
  });

  // Re-enable buttons when the browser restores the page from its back/forward cache
  window.addEventListener("pageshow", function (e) {
    if (e.persisted) document.querySelectorAll("button[data-busy]").forEach(function (b) { b.disabled = false; b.removeAttribute("data-busy"); });
  });

  // Copy family link
  document.querySelectorAll("[data-copy]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var input = document.getElementById(btn.getAttribute("data-copy"));
      if (!input) return;
      input.select();
      var done = function () { btn.textContent = "Copied"; setTimeout(function () { btn.textContent = "Copy link"; }, 2000); };
      if (navigator.clipboard) { navigator.clipboard.writeText(input.value).then(done, function () { document.execCommand("copy"); done(); }); }
      else { document.execCommand("copy"); done(); }
    });
  });

  // Live search on the class board: results appear as you type (2+ letters)
  var ls = document.querySelector("form[data-live-search]");
  if (ls) {
    var input = ls.querySelector("input[name=q]");
    var list = document.getElementById(ls.getAttribute("data-results"));
    var empty = document.getElementById("search-empty");
    var timer = null, seq = 0;
    var el = function (tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text) e.textContent = text; return e; };
    var hidden = function (name, value) { var i = el("input"); i.type = "hidden"; i.name = name; i.value = value; return i; };
    var action = ls.getAttribute("data-action") || "/teacher/checkin";
    if (ls.hasAttribute("data-action")) ls.addEventListener("submit", function (e) { e.preventDefault(); });
    var minLen = parseInt(ls.getAttribute("data-min") || "2", 10);
    var render = function (items, q) {
      list.textContent = "";
      items.forEach(function (c) {
        var li = el("li", "board-item");
        var who = el("div", "who");
        who.appendChild(el("strong", "", c.name));
        if (c.cls) who.appendChild(el("span", "muted", c.cls));
        li.appendChild(who);
        if (c.status) {
          li.appendChild(el("span", "status status-in", c.status));
        } else {
          var f = el("form");
          f.method = "post"; f.action = action;
          f.appendChild(hidden("csrf_token", ls.getAttribute("data-csrf")));
          f.appendChild(hidden("child_id", c.id));
          if (ls.hasAttribute("data-cls")) f.appendChild(hidden("cls", ls.getAttribute("data-cls")));
          var b = el("button", "btn btn-primary btn-block", "Check in " + c.first);
          b.type = "submit";
          f.appendChild(b);
          li.appendChild(f);
        }
        list.appendChild(li);
      });
      if (empty) empty.hidden = !(q.length >= minLen && items.length === 0);
    };
    input.addEventListener("input", function () {
      clearTimeout(timer);
      var q = input.value.trim();
      if (q.length < minLen) { render([], q); return; }
      timer = setTimeout(function () {
        var mine = ++seq;
        fetch(ls.getAttribute("data-live-search") + "?q=" + encodeURIComponent(q),
              { credentials: "same-origin", headers: { "Accept": "application/json" } })
          .then(function (r) { return r.ok ? r.json() : null; })
          .then(function (data) { if (data && mine === seq) render(data.results, q); })
          .catch(function () {});
      }, 250);
    });
  }

  // Check-in station: return to the start screen after a confirmation
  var back = document.querySelector("[data-return-after]");
  if (back) {
    setTimeout(function () { window.location.href = back.getAttribute("href"); },
               parseInt(back.getAttribute("data-return-after"), 10) * 1000);
  }

  // Live refresh: reload when attendance changes, never while someone is typing
  var poll = document.querySelector("[data-poll]");
  if (poll) {
    var url = poll.getAttribute("data-poll");
    var every = parseInt(poll.getAttribute("data-every") || "10", 10) * 1000;
    var last = null;
    var tick = function () {
      if (document.hidden) return;
      fetch(url, { credentials: "same-origin", headers: { "Accept": "application/json" } })
        .then(function (r) { return r.ok ? r.json() : null; })
        .then(function (data) {
          if (!data) return;
          if (last !== null && data.v !== last) {
            var a = document.activeElement;
            var typing = a && (a.tagName === "INPUT" || a.tagName === "TEXTAREA" || a.tagName === "SELECT") && a.value;
            var openDetails = document.querySelector("details[open]");
            if (!typing && !openDetails) { window.location.reload(); return; }
          }
          last = data.v;
        })
        .catch(function () {});
    };
    tick();
    setInterval(tick, every);
  }
})();
