"""Outbound email (SMTP) and SMS (Twilio REST via httpx). Both are optional and fail soft."""
import logging
import re
from email.message import EmailMessage
from email.utils import formataddr, make_msgid

import aiosmtplib
import httpx
from jinja2 import Environment, FileSystemLoader, select_autoescape

from app import config

logger = logging.getLogger("notify")

_env = Environment(loader=FileSystemLoader("app/templates/emails"), autoescape=select_autoescape(["html"]))

EMAIL_RE = re.compile(r"^[^@\s<>]+@[^@\s<>]+\.[^@\s<>]+$")


def valid_email(addr: str) -> bool:
    return bool(addr) and len(addr) <= 254 and bool(EMAIL_RE.match(addr))


def normalize_phone(raw: str) -> str:
    """Return an E.164 number (+1 assumed for 10-digit North American numbers) or ''."""
    digits = re.sub(r"\D", "", raw or "")
    if len(digits) == 10:
        return "+1" + digits
    if len(digits) == 11 and digits.startswith("1"):
        return "+" + digits
    if (raw or "").strip().startswith("+") and 8 <= len(digits) <= 15:
        return "+" + digits
    return ""


def render_email(template: str, **ctx) -> str:
    from app.templating import on_color
    if "s" in ctx:
        ctx.setdefault("on_brand", on_color(ctx["s"].brand_color))
    return _env.get_template(template).render(**ctx)


async def send_email(to: list[str], subject: str, html: str, text: str, from_name: str = "",
                     attachments: list[tuple[str, bytes, str]] | None = None) -> bool:
    to = [t for t in to if valid_email(t)]
    if not to or not config.smtp_configured():
        return False
    msg = EmailMessage()
    msg["Subject"] = subject[:200]
    msg["From"] = formataddr((from_name[:80], config.SMTP_FROM)) if from_name else config.SMTP_FROM
    msg["To"] = config.SMTP_FROM if len(to) > 1 else to[0]
    msg["Message-ID"] = make_msgid()
    msg.set_content(text)
    msg.add_alternative(html, subtype="html")
    for filename, data, mime in attachments or []:
        maintype, subtype = mime.split("/", 1)
        msg.add_attachment(data, maintype=maintype, subtype=subtype, filename=filename)
    try:
        await aiosmtplib.send(
            msg, recipients=to, hostname=config.SMTP_HOST, port=config.SMTP_PORT,
            username=config.SMTP_USER or None, password=config.SMTP_PASSWORD or None,
            start_tls=config.SMTP_SECURITY == "starttls", use_tls=config.SMTP_SECURITY == "ssl", timeout=30)
        return True
    except Exception as e:  # network / auth errors must not crash jobs
        logger.error("Email send failed (%d recipients): %s", len(to), type(e).__name__)
        return False


async def send_sms(to: str, body: str) -> bool:
    number = normalize_phone(to)
    if not number or not config.sms_configured():
        return False
    url = f"https://api.twilio.com/2010-04-01/Accounts/{config.TWILIO_ACCOUNT_SID}/Messages.json"
    try:
        async with httpx.AsyncClient(timeout=20) as client:
            resp = await client.post(url, data={"To": number, "From": config.TWILIO_FROM, "Body": body[:600]},
                                     auth=(config.TWILIO_ACCOUNT_SID, config.TWILIO_AUTH_TOKEN))
        if resp.status_code >= 300:
            logger.error("SMS send failed: HTTP %s", resp.status_code)
            return False
        return True
    except httpx.HTTPError as e:
        logger.error("SMS send failed: %s", type(e).__name__)
        return False
