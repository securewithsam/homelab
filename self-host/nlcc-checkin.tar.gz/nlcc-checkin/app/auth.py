"""Passwords, staff sessions, CSRF, family link tokens, rate limiting, MFA and access dependencies."""
import base64
import hashlib
import hmac
import io
import secrets
import time
from collections import defaultdict, deque
from datetime import datetime, timedelta, timezone

import bcrypt
import pyotp
import qrcode
from fastapi import Depends, HTTPException, Request
from itsdangerous import BadSignature, SignatureExpired, URLSafeSerializer, URLSafeTimedSerializer
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import COOKIE_SECURE, IDLE_TIMEOUT, REQUIRE_ADMIN_MFA, SECRET_KEY, SESSION_MAX_AGE
from app.database import get_db
from app.models import Family, Staff

SESSION_COOKIE = "nlcc_session"
MFA_COOKIE = "nlcc_mfa"
CSRF_COOKIE = "nlcc_csrf"
MIN_PASSWORD = 8
MAX_FAILED = 5
LOCK_MINUTES = 15

_session_ser = URLSafeTimedSerializer(SECRET_KEY, salt="staff-session")
_mfa_ser = URLSafeTimedSerializer(SECRET_KEY, salt="mfa-pending")
_family_ser = URLSafeSerializer(SECRET_KEY, salt="family-link")


# ---------- redirects used as exceptions ----------
class RedirectTo(Exception):
    def __init__(self, url: str):
        self.url = url


# ---------- passwords ----------
def hash_password(pw: str) -> str:
    return bcrypt.hashpw(pw.encode()[:72], bcrypt.gensalt(rounds=12)).decode()


def verify_password(pw: str, hashed: str | None) -> bool:
    if not hashed:
        bcrypt.checkpw(b"timing-equalizer", bcrypt.hashpw(b"x", bcrypt.gensalt(rounds=4)))
        return False
    try:
        return bcrypt.checkpw(pw.encode()[:72], hashed.encode())
    except ValueError:
        return False


def password_problem(pw: str) -> str | None:
    if len(pw) < MIN_PASSWORD:
        return f"Use at least {MIN_PASSWORD} characters."
    if len(pw) > 128:
        return "Use 128 characters or fewer."
    return None


# ---------- staff sessions ----------
def make_session(staff: Staff) -> str:
    now = int(time.time())
    return _session_ser.dumps({"uid": staff.id, "sv": staff.session_version, "iat": now, "seen": now,
                               "n": secrets.token_hex(8)})


def read_session(token: str | None) -> dict | None:
    if not token:
        return None
    try:
        data = _session_ser.loads(token, max_age=IDLE_TIMEOUT + 60)
    except (BadSignature, SignatureExpired):
        return None
    now = int(time.time())
    if now - int(data.get("iat", 0)) > SESSION_MAX_AGE or now - int(data.get("seen", 0)) > IDLE_TIMEOUT:
        return None
    return data


def refresh_session(data: dict) -> str:
    data = dict(data, seen=int(time.time()))
    return _session_ser.dumps(data)


def set_cookie(response, key: str, value: str, max_age: int) -> None:
    response.set_cookie(key=key, value=value, httponly=True, secure=COOKIE_SECURE, samesite="lax",
                        max_age=max_age, path="/")


def make_mfa_pending(staff: Staff) -> str:
    return _mfa_ser.dumps({"uid": staff.id, "sv": staff.session_version})


def read_mfa_pending(token: str | None) -> dict | None:
    if not token:
        return None
    try:
        return _mfa_ser.loads(token, max_age=300)
    except (BadSignature, SignatureExpired):
        return None


# ---------- CSRF (seed cookie + HMAC, works for staff and family pages) ----------
def new_csrf_seed() -> str:
    return secrets.token_urlsafe(24)


def csrf_token_for(seed: str) -> str:
    return hmac.new(SECRET_KEY.encode(), f"csrf:{seed}".encode(), hashlib.sha256).hexdigest()


def csrf_token(request: Request) -> str:
    seed = getattr(request.state, "csrf_seed", "") or request.cookies.get(CSRF_COOKIE, "")
    return csrf_token_for(seed) if seed else ""


async def require_csrf(request: Request) -> None:
    if request.method in ("GET", "HEAD", "OPTIONS"):
        return
    seed = request.cookies.get(CSRF_COOKIE, "")
    form = await request.form()
    sent = str(form.get("csrf_token", ""))
    if not seed or not sent or not hmac.compare_digest(sent, csrf_token_for(seed)):
        raise HTTPException(status_code=403, detail="This form expired. Go back, refresh the page and try again.")


# ---------- family links ----------
def family_token(family: Family) -> str:
    return _family_ser.dumps({"f": family.id, "v": family.link_version})


def read_family_token(token: str) -> dict | None:
    if not token or len(token) > 300:
        return None
    try:
        data = _family_ser.loads(token)
        return data if isinstance(data, dict) else None
    except BadSignature:
        return None


# ---------- rate limiting (in-memory, per worker) ----------
_hits: dict[str, deque] = defaultdict(deque)


def client_ip(request: Request) -> str:
    return request.client.host if request.client else "unknown"


def rate_limited(key: str, limit: int, window: int = 60) -> bool:
    now = time.monotonic()
    q = _hits[key]
    while q and now - q[0] > window:
        q.popleft()
    if len(q) >= limit:
        return True
    q.append(now)
    if len(_hits) > 20000:  # crude memory cap
        _hits.clear()
    return False


# ---------- lockout ----------
def is_locked(staff: Staff) -> bool:
    if not staff.locked_until:
        return False
    lu = staff.locked_until if staff.locked_until.tzinfo else staff.locked_until.replace(tzinfo=timezone.utc)
    return lu > datetime.now(timezone.utc)


def register_failure(staff: Staff) -> bool:
    """Returns True if this failure locked the account."""
    staff.failed_logins = (staff.failed_logins or 0) + 1
    if staff.failed_logins >= MAX_FAILED:
        staff.locked_until = datetime.now(timezone.utc) + timedelta(minutes=LOCK_MINUTES)
        staff.failed_logins = 0
        return True
    return False


# ---------- MFA ----------
def new_mfa_secret() -> str:
    return pyotp.random_base32()


def mfa_qr_data_uri(secret: str, email: str, issuer: str) -> str:
    uri = pyotp.TOTP(secret).provisioning_uri(name=email, issuer_name=issuer[:40] or "Check-in")
    img = qrcode.make(uri, box_size=6, border=2)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()


def verify_totp(secret: str | None, code: str) -> bool:
    code = (code or "").replace(" ", "")
    return bool(secret and code.isdigit() and len(code) == 6 and pyotp.TOTP(secret).verify(code, valid_window=1))


def new_backup_codes() -> tuple[list[str], str]:
    codes = [f"{secrets.randbelow(10**8):08d}" for _ in range(10)]
    hashed = "\n".join(bcrypt.hashpw(c.encode(), bcrypt.gensalt(rounds=10)).decode() for c in codes)
    return codes, hashed


def use_backup_code(staff: Staff, code: str) -> bool:
    code = (code or "").replace(" ", "").replace("-", "")
    if not code.isdigit():
        return False
    hashes = [h for h in (staff.mfa_backup_codes or "").splitlines() if h]
    for h in hashes:
        if bcrypt.checkpw(code.encode(), h.encode()):
            hashes.remove(h)
            staff.mfa_backup_codes = "\n".join(hashes)
            return True
    return False


# ---------- dependencies ----------
class NotAuthenticated(Exception):
    pass


async def current_staff(request: Request, db: AsyncSession = Depends(get_db)) -> Staff:
    data = read_session(request.cookies.get(SESSION_COOKIE))
    if not data:
        raise NotAuthenticated()
    staff = await db.get(Staff, data.get("uid"))
    if (not staff or not staff.is_active or not staff.can_login
            or staff.session_version != data.get("sv")):
        raise NotAuthenticated()
    request.state.refresh_session = refresh_session(data)
    request.state.staff = staff
    return staff


async def staff_any(request: Request, staff: Staff = Depends(current_staff)) -> Staff:
    if staff.is_admin and REQUIRE_ADMIN_MFA and not staff.mfa_enabled:
        if not request.url.path.startswith("/profile"):
            raise RedirectTo("/profile?mfa_required=1")
    return staff


async def admin_only(staff: Staff = Depends(staff_any)) -> Staff:
    if not staff.is_admin:
        raise HTTPException(status_code=403, detail="This page is for administrators.")
    return staff
