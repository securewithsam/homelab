"""Small, idempotent schema upgrades for existing installs (create_all never alters tables)."""
import logging

from sqlalchemy import inspect, text
from sqlalchemy.ext.asyncio import AsyncEngine

logger = logging.getLogger("migrations")

# table -> [(column, SQL type and default)]
ADD_COLUMNS = {
    "attendance": [("child_name", "VARCHAR(160) DEFAULT '' NOT NULL")],
    "families": [("is_guest", "BOOLEAN DEFAULT FALSE NOT NULL")],
    "roster_entries": [("note", "TEXT DEFAULT '' NOT NULL")],
    "app_settings": [("email_teachers_on_checkin", "BOOLEAN DEFAULT TRUE NOT NULL"),
                     ("kiosk_token", "VARCHAR(64) DEFAULT '' NOT NULL"),
                     ("kiosk_guests_on", "BOOLEAN DEFAULT TRUE NOT NULL")],
}


def _missing(sync_conn) -> list[tuple[str, str, str]]:
    insp = inspect(sync_conn)
    out = []
    for table, cols in ADD_COLUMNS.items():
        if not insp.has_table(table):
            continue
        have = {c["name"] for c in insp.get_columns(table)}
        out += [(table, name, ddl) for name, ddl in cols if name not in have]
    return out


async def migrate(engine: AsyncEngine) -> None:
    pg = engine.dialect.name == "postgresql"
    try:
        async with engine.begin() as conn:
            if pg:  # serialize across the two web workers and the scheduler
                await conn.execute(text("SELECT pg_advisory_xact_lock(480201)"))
            for table, name, ddl in await conn.run_sync(_missing):
                await conn.execute(text(f"ALTER TABLE {table} ADD COLUMN {name} {ddl}"))
                logger.info("Added column %s.%s", table, name)
            # Keep attendance history when a child is deleted
            await conn.execute(text(
                "UPDATE attendance SET child_name = (SELECT TRIM(first_name || ' ' || last_name) FROM children "
                "WHERE children.id = attendance.child_id) WHERE child_name = '' AND child_id IS NOT NULL"))
            if pg:
                await conn.execute(text("ALTER TABLE attendance ALTER COLUMN child_id DROP NOT NULL"))
                await conn.execute(text("ALTER TABLE attendance DROP CONSTRAINT IF EXISTS attendance_child_id_fkey"))
                await conn.execute(text(
                    "ALTER TABLE attendance ADD CONSTRAINT attendance_child_id_fkey FOREIGN KEY (child_id) "
                    "REFERENCES children(id) ON DELETE SET NULL"))
            # Old default brand color was too light for white button text
            await conn.execute(text("UPDATE app_settings SET brand_color = '#3D5AFE' WHERE brand_color = '#7C9CFF'"))
    except Exception:
        logger.exception("Migration failed")
