"""Runtime configuration loaded from environment variables. Secrets never live in the DB or UI."""
import os
import sys


def _req(name: str) -> str:
    val = os.environ.get(name, "").strip()
    if not val:
        print(f"FATAL: required environment variable {name} is not set", file=sys.stderr)
        sys.exit(1)
    return val


def _bool(name: str, default: str) -> bool:
    return os.environ.get(name, default).strip().lower() in ("1", "true", "yes", "on")


SECRET_KEY: str = _req("SECRET_KEY")
if len(SECRET_KEY) < 32:
    print("FATAL: SECRET_KEY must be at least 32 characters", file=sys.stderr)
    sys.exit(1)

DATABASE_URL: str = _req("DATABASE_URL")
APP_PORT: int = int(os.environ.get("APP_PORT", "4802"))
COOKIE_SECURE: bool = _bool("COOKIE_SECURE", "true")
REQUIRE_ADMIN_MFA: bool = _bool("REQUIRE_ADMIN_MFA", "false")

ADMIN_EMAIL: str = os.environ.get("ADMIN_EMAIL", "").strip().lower()
ADMIN_PASSWORD: str = os.environ.get("ADMIN_PASSWORD", "")

# Default public URL used in email links until set in Admin > Settings
PUBLIC_BASE_URL: str = os.environ.get("PUBLIC_BASE_URL", "").rstrip("/")
DEFAULT_TIMEZONE: str = os.environ.get("TZ_NAME", "America/Toronto")

# Email (SMTP) — optional; the app runs without it, notifications are skipped
SMTP_HOST: str = os.environ.get("SMTP_HOST", "")
SMTP_PORT: int = int(os.environ.get("SMTP_PORT", "587"))
SMTP_USER: str = os.environ.get("SMTP_USER", "")
SMTP_PASSWORD: str = os.environ.get("SMTP_PASSWORD", "")
SMTP_FROM: str = os.environ.get("SMTP_FROM", "")
SMTP_SECURITY: str = os.environ.get("SMTP_SECURITY", "starttls").lower()  # starttls | ssl | none

# SMS via Twilio — optional
TWILIO_ACCOUNT_SID: str = os.environ.get("TWILIO_ACCOUNT_SID", "")
TWILIO_AUTH_TOKEN: str = os.environ.get("TWILIO_AUTH_TOKEN", "")
TWILIO_FROM: str = os.environ.get("TWILIO_FROM", "")

UPLOAD_DIR: str = os.environ.get("UPLOAD_DIR", "/app/uploads")
MAX_LOGO_MB: int = int(os.environ.get("MAX_LOGO_MB", "2"))

SESSION_MAX_AGE = 8 * 3600
IDLE_TIMEOUT = 60 * 60  # sign out after 1 hour of inactivity


def smtp_configured() -> bool:
    return bool(SMTP_HOST and SMTP_FROM)


def sms_configured() -> bool:
    return bool(TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN and TWILIO_FROM)
