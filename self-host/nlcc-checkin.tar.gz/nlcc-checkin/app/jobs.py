"""Reminder and report jobs. Called by the scheduler and by the 'Send now' buttons in Admin."""
import logging
from datetime import date, datetime, timezone

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app import config
from app.attendance import records_for, service_day, today
from app.database import async_session
from app.audit import log_event
from app.auth import family_token
from app.models import AppSettings, Attendance, Child, Family, RosterEntry
from app.notify import render_email, send_email, send_sms
from app.reports import build_monthly, build_weekly, report_filename
from app.settings_service import base_url, get_settings, report_recipients
from app.timeutil import fmt_hhmm, fmt_time

logger = logging.getLogger("jobs")


def family_url(s: AppSettings, fam: Family, path: str = "") -> str:
    return f"{base_url(s)}/f/{family_token(fam)}{path}"


async def _active_families(db: AsyncSession) -> list[Family]:
    rows = await db.execute(select(Family).options(selectinload(Family.guardians), selectinload(Family.children))
                            .where(Family.is_active.is_(True)))
    return list(rows.scalars())


async def _notify_family(s: AppSettings, fam: Family, kind: str, kids: list[str]) -> tuple[int, int]:
    link = family_url(s, fam)
    prefs = family_url(s, fam, "/notifications")
    names = ", ".join(kids)
    if kind == "checkin":
        subject = f"Check in for {s.program_name} today"
        lead = f"{s.program_name} check-in is open. Tap the button to check in {names}."
        button = "Check in now"
        sms = f"{s.church_name}: {s.program_name} check-in is open. Check in {names}: {link}"
    else:
        subject = f"Time to pick up from {s.program_name}"
        lead = f"{s.program_name} is wrapping up. Tap the button when you pick up {names}."
        button = "Check out"
        sms = f"{s.church_name}: time to pick up {names}. Check out: {link}"
    html = render_email("reminder.html", s=s, lead=lead, button=button, link=link, prefs=prefs)
    text = f"{lead}\n\n{button}: {link}\n\nChange or turn off these messages: {prefs}\n"
    sent_e = sent_s = 0
    for g in fam.guardians:
        if g.notify_email and g.email and await send_email([g.email], subject, html, text, from_name=s.church_name):
            sent_e += 1
        if s.sms_enabled and g.notify_sms and g.phone and await send_sms(g.phone, sms + " Reply STOP to opt out."):
            sent_s += 1
    return sent_e, sent_s


async def send_checkin_reminders(db: AsyncSession, s: AppSettings) -> str:
    if not base_url(s):
        return "Skipped: set the public web address in Settings first."
    d = today(s)
    total_e = total_s = 0
    for fam in await _active_families(db):
        kids = [c for c in fam.children if c.is_active]
        if not kids:
            continue
        done = await records_for(db, [c.id for c in kids], d)
        waiting = [c.first_name for c in kids if c.id not in done]
        if waiting:
            e, sm = await _notify_family(s, fam, "checkin", waiting)
            total_e += e
            total_s += sm
    return f"Check-in reminders: {total_e} emails, {total_s} texts."


async def send_checkout_reminders(db: AsyncSession, s: AppSettings) -> str:
    if not base_url(s):
        return "Skipped: set the public web address in Settings first."
    d = today(s)
    total_e = total_s = 0
    for fam in await _active_families(db):
        kids = [c for c in fam.children if c.is_active]
        recs = await records_for(db, [c.id for c in kids], d)
        here = [c.first_name for c in kids if c.id in recs and not recs[c.id].checked_out_at]
        if here:  # only families whose children are still checked in
            e, sm = await _notify_family(s, fam, "checkout", here)
            total_e += e
            total_s += sm
    return f"Check-out reminders: {total_e} emails, {total_s} texts."


def _teacher_lead(s: AppSettings, r: RosterEntry, service_date: date, label: str, when: str) -> str:
    cls = r.class_group.name if r.class_group else "any class that needs help"
    room = f" in {r.class_group.room}" if r.class_group and r.class_group.room else ""
    return (f"Hi {r.staff.name.split(' ')[0]}, you're on the roster for {label} {when}, "
            f"{service_date.strftime('%A, %B %-d')}, with {cls}{room}.")


async def send_teacher_reminders(db: AsyncSession, s: AppSettings, service_date: date,
                                 only_ids: list[str] | None = None, message: str = "") -> str:
    """Email rostered teachers for a date. only_ids limits it to some roster entries; message is added."""
    sd = await service_day(db, s, service_date)
    label = sd.name if sd else s.program_name
    rows = await db.execute(select(RosterEntry).options(selectinload(RosterEntry.staff),
                                                        selectinload(RosterEntry.class_group))
                            .where(RosterEntry.service_date == service_date))
    sent = 0
    local_today = today(s)
    when = "today" if service_date == local_today else ("tomorrow" if (service_date - local_today).days == 1 else "on")
    for r in rows.scalars():
        st = r.staff
        if only_ids is not None and r.id not in only_ids:
            continue
        if not st.is_active or not st.email or (only_ids is None and not st.remind_by_email):
            continue
        lead = _teacher_lead(s, r, service_date, label, when)
        if sd:
            lead += f" Check-in opens at {fmt_hhmm(sd.opens)}."
        details = []
        if r.note:
            details.append(("Lesson", r.note))
        if message:
            details.append(("Message", message))
        link = f"{base_url(s)}/teacher" if (st.can_login and base_url(s)) else ""
        html = render_email("reminder.html", s=s, lead=lead, details=details,
                            button="Open the class board" if link else "", link=link, prefs="")
        text = lead + "".join(f"\n\n{k}: {v}" for k, v in details) + (f"\n\n{link}" if link else "")
        subject = f"You're teaching {label} {'on ' + service_date.strftime('%b %-d') if when == 'on' else when}"
        if await send_email([st.email], subject, html, text, from_name=s.church_name):
            sent += 1
            r.reminded_at = datetime.now(timezone.utc)
    await db.flush()
    return f"Teacher reminders: {sent} emails."


async def notify_teachers_of_checkins(att_ids: list[str]) -> None:
    """Background task: email each class's rostered teachers about new check-ins (one email per class)."""
    if not att_ids:
        return
    async with async_session() as db:
        s = await get_settings(db)
        if not s.email_teachers_on_checkin:
            return
        rows = await db.execute(select(Attendance).options(selectinload(Attendance.child)
                                                           .selectinload(Child.class_group))
                                .where(Attendance.id.in_(att_ids)))
        atts = [a for a in rows.scalars() if a.child]
        if not atts:
            return
        d = atts[0].service_date
        roster = list((await db.execute(select(RosterEntry).options(selectinload(RosterEntry.staff))
                                        .where(RosterEntry.service_date == d))).scalars())
        by_class: dict[str | None, list[Attendance]] = {}
        for a in atts:
            by_class.setdefault(a.child.class_id, []).append(a)
        for class_id, items in by_class.items():
            teachers = [r.staff for r in roster if r.class_id == class_id and class_id] or \
                       [r.staff for r in roster if r.class_id is None]
            to = sorted({t.email for t in teachers if t.is_active and t.email and t.remind_by_email})
            if not to:
                continue
            cls = items[0].class_name
            names = ", ".join(f"{a.child.full_name}" for a in items)
            lead = f"{names} checked in to {cls} at {fmt_time(items[0].checked_in_at, s.timezone)}."
            # Care notes stay on the class board, out of inboxes; the email only flags that one exists.
            flagged = [a.child.first_name for a in items if a.child.care_notes]
            details = [("Care note", f"{', '.join(flagged)} has a care note. Check the class board.")] if flagged else []
            link = f"{base_url(s)}/teacher" if base_url(s) else ""
            html = render_email("reminder.html", s=s, lead=lead, details=details,
                                button="Open the class board" if link else "", link=link, prefs="")
            text = lead + "".join(f"\n{k}: {v}" for k, v in details)
            subject = f"Checked in: {names}"[:120]
            for addr in to:
                await send_email([addr], subject, html, text, from_name=s.church_name)


async def send_weekly_report(db: AsyncSession, s: AppSettings, d: date) -> str:
    to = report_recipients(s)
    if not to:
        return "Skipped: add report recipients in Settings."
    sd = await service_day(db, s, d)
    name = sd.name if sd else s.program_name
    pdf = await build_weekly(db, s, d, name)
    label = d.isoformat()
    html = render_email("report.html", s=s, title=f"{name} attendance for {d.strftime('%A, %B %-d, %Y')}",
                        body="The attendance report is attached. Rows highlighted in red need follow-up.")
    ok = await send_email(to, f"{name} attendance, {d.strftime('%b %-d, %Y')}", html,
                          "The attendance report is attached.", from_name=s.church_name,
                          attachments=[(report_filename(s, "weekly", label), pdf, "application/pdf")])
    return f"Weekly report {'emailed' if ok else 'NOT sent (check email settings)'} to {len(to)} recipient(s)."


async def send_monthly_report(db: AsyncSession, s: AppSettings, year: int, month: int) -> str:
    to = report_recipients(s)
    if not to:
        return "Skipped: add report recipients in Settings."
    pdf = await build_monthly(db, s, year, month)
    label = f"{year}-{month:02d}"
    title = date(year, month, 1).strftime("%B %Y")
    html = render_email("report.html", s=s, title=f"Monthly report for {title}",
                        body="The monthly attendance and supervision report is attached.")
    ok = await send_email(to, f"{s.program_name} monthly report, {title}", html,
                          "The monthly report is attached.", from_name=s.church_name,
                          attachments=[(report_filename(s, "monthly", label), pdf, "application/pdf")])
    return f"Monthly report {'emailed' if ok else 'NOT sent (check email settings)'} to {len(to)} recipient(s)."


async def run_and_log(db: AsyncSession, actor: str, action: str, coro) -> str:
    try:
        result = await coro
    except Exception as e:
        logger.exception("Job %s failed", action)
        result = f"Failed: {type(e).__name__}"
    log_event(db, actor=actor, action=action, detail=result)
    await db.commit()
    logger.info("%s: %s", action, result)
    return result


def email_ready() -> bool:
    return config.smtp_configured()
