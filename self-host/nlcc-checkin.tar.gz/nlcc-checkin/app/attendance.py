"""Check-in / pickup / release rules shared by the family page and the teacher board."""
import secrets
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta, timezone

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.models import AppSettings, Attendance, Child, Family, ServiceEvent
from app.timeutil import fmt_hhmm, now_local, parse_hhmm


def today(s: AppSettings) -> date:
    return now_local(s.timezone).date()


@dataclass
class ServiceDay:
    day: date
    name: str
    opens: str
    closes: str
    checkin_reminder: str
    checkout_reminder: str
    report_time: str
    is_event: bool
    scheduled: bool = True  # False for "open any day" check-in: no reminders or reports


def _shift(hhmm: str, minutes: int) -> str:
    t = parse_hhmm(hhmm)
    dt = datetime.combine(date.today(), t) + timedelta(minutes=minutes)
    if dt.date() != date.today():  # clamp to the same day
        dt = datetime.combine(date.today(), time(0, 0) if minutes < 0 else time(23, 59))
    return dt.strftime("%H:%M")


def day_from(s: AppSettings, d: date, ev: ServiceEvent | None) -> ServiceDay | None:
    if ev and ev.cancelled:
        return None
    if ev:
        return ServiceDay(d, ev.name or s.program_name, _shift(ev.start_time, -60), _shift(ev.end_time, 90),
                          _shift(ev.start_time, -5), ev.end_time, _shift(ev.end_time, 30), True)
    if d.weekday() == 6:
        return ServiceDay(d, s.program_name, s.checkin_opens, s.checkin_closes, s.checkin_reminder_time,
                          s.checkout_reminder_time, s.weekly_report_time, False)
    return None


async def events_between(db: AsyncSession, start: date, end: date) -> dict[date, ServiceEvent]:
    rows = await db.execute(select(ServiceEvent).where(ServiceEvent.event_date >= start,
                                                       ServiceEvent.event_date <= end))
    return {e.event_date: e for e in rows.scalars()}


async def service_day(db: AsyncSession, s: AppSettings, d: date) -> ServiceDay | None:
    ev = (await events_between(db, d, d)).get(d)
    return day_from(s, d, ev)


async def next_service_day(db: AsyncSession, s: AppSettings, after: date) -> ServiceDay | None:
    evs = await events_between(db, after, after + timedelta(days=70))
    for i in range(71):
        d = after + timedelta(days=i)
        sd = day_from(s, d, evs.get(d))
        if sd:
            return sd
    return None


async def checkin_window(db: AsyncSession, s: AppSettings) -> tuple[bool, str]:
    """Returns (is_open, message for parents when closed)."""
    now = now_local(s.timezone)
    sd = await service_day(db, s, now.date())
    if sd is None and s.open_any_day:
        sd = ServiceDay(now.date(), s.program_name, s.checkin_opens, s.checkin_closes, "", "", "", False, False)
    if sd and parse_hhmm(sd.opens) <= now.time() <= parse_hhmm(sd.closes):
        return True, ""
    if sd and now.time() < parse_hhmm(sd.opens):
        return False, f"Check-in opens today at {fmt_hhmm(sd.opens)}."
    nxt = await next_service_day(db, s, now.date() + timedelta(days=1))
    if not nxt:
        return False, "Check-in is closed. No upcoming classes are on the calendar."
    return False, f"Check-in is closed. Next: {nxt.name}, {nxt.day.strftime('%A, %B %-d')}, opening at {fmt_hhmm(nxt.opens)}."


async def records_for(db: AsyncSession, child_ids: list[str], d: date) -> dict[str, Attendance]:
    if not child_ids:
        return {}
    rows = await db.execute(select(Attendance).where(Attendance.child_id.in_(child_ids),
                                                     Attendance.service_date == d))
    return {a.child_id: a for a in rows.scalars()}


async def day_records(db: AsyncSession, d: date) -> list[Attendance]:
    rows = await db.execute(
        select(Attendance).options(selectinload(Attendance.child).selectinload(Child.family)
                                   .selectinload(Family.guardians))
        .where(Attendance.service_date == d).order_by(Attendance.class_name, Attendance.checked_in_at))
    return list(rows.scalars())


async def check_in(db: AsyncSession, child: Child, d: date, by: str) -> Attendance | None:
    """Idempotent: returns the existing record if the child is already checked in today."""
    existing = (await records_for(db, [child.id], d)).get(child.id)
    if existing:
        return existing
    att = Attendance(child_id=child.id, child_name=child.full_name[:160], service_date=d, checked_in_by=by[:160],
                     class_name=child.class_group.name if child.class_group else "Unassigned")
    try:
        async with db.begin_nested():  # savepoint: a double tap from two phones can't poison the session
            db.add(att)
    except IntegrityError:
        return (await records_for(db, [child.id], d)).get(child.id)
    return att


def request_pickup(att: Attendance, s: AppSettings, person: str, by: str) -> None:
    now = datetime.now(timezone.utc)
    att.pickup_person = person[:120]
    if s.require_teacher_release:
        att.pickup_requested_at = now
        att.pickup_code = f"{secrets.randbelow(10000):04d}"
    else:
        att.pickup_requested_at = now
        att.checked_out_at = now
        att.checked_out_by = by[:160]


def release(att: Attendance, staff_name: str, code_ok: bool, person: str | None = None) -> None:
    now = datetime.now(timezone.utc)
    if person:
        att.pickup_person = person[:120]
    if not att.pickup_requested_at:
        att.pickup_requested_at = now
    att.checked_out_at = now
    att.checked_out_by = f"Teacher: {staff_name}"[:160]
    att.released_by = staff_name[:120]
    att.code_verified = code_ok
