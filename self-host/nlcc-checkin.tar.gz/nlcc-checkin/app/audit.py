"""log_event(): one audit function used everywhere. Caller commits."""
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import AuditLog


def log_event(db: AsyncSession, *, actor: str, action: str, target_type: str = "",
              target_id: str = "", detail: str = "", ip: str = "") -> None:
    db.add(AuditLog(actor=(actor or "system")[:254], action=action[:40], target_type=target_type[:40],
                    target_id=(target_id or "")[:36], detail=(detail or "")[:2000], ip_address=(ip or "")[:64]))
