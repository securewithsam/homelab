"""Admin: families (guardians, children, private links), classes, staff accounts and the teacher roster."""
import base64
import io

import qrcode
from fastapi import APIRouter, Depends, Form, Request
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.attendance import records_for, today
from app.audit import log_event
from app.auth import admin_only, client_ip, hash_password, password_problem, require_csrf
from app.database import get_db
from app.jobs import family_url
from app.models import Child, ClassGroup, Family, Guardian, RosterEntry, Staff
from app.notify import normalize_phone, render_email, send_email, valid_email
from app.settings_service import base_url, get_settings
from app.templating import redirect, render

router = APIRouter(prefix="/admin", dependencies=[Depends(require_csrf)])


def _clean(v: str, n: int) -> str:
    return (v or "").strip()[:n]


async def _classes(db: AsyncSession, active_only: bool = True) -> list[ClassGroup]:
    q = select(ClassGroup).order_by(ClassGroup.sort_order, ClassGroup.name)
    if active_only:
        q = q.where(ClassGroup.is_active.is_(True))
    return list((await db.execute(q)).scalars())


async def _family(db: AsyncSession, fid: str) -> Family | None:
    return (await db.execute(select(Family).options(selectinload(Family.guardians), selectinload(Family.children))
                             .where(Family.id == fid))).scalar_one_or_none()


def _qr(url: str) -> str:
    buf = io.BytesIO()
    qrcode.make(url, box_size=6, border=2).save(buf, format="PNG")
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()


# ---------------- families ----------------
@router.get("/families")
async def families(request: Request, q: str = "", me: Staff = Depends(admin_only), db: AsyncSession = Depends(get_db)):
    stmt = select(Family).options(selectinload(Family.guardians), selectinload(Family.children)).order_by(Family.name)
    q = q.strip()[:60]
    if q:
        stmt = stmt.where(Family.name.ilike(f"%{q}%"))
    fams = list((await db.execute(stmt.limit(500))).scalars())
    return await render(request, db, "admin/families.html", {"families": fams, "q": q})


@router.post("/families")
async def family_create(request: Request, name: str = Form(""), me: Staff = Depends(admin_only),
                        db: AsyncSession = Depends(get_db)):
    name = _clean(name, 120)
    if not name:
        return redirect("/admin/families", "Enter a family name.", True)
    fam = Family(name=name)
    db.add(fam)
    await db.flush()
    log_event(db, actor=me.email, action="family.create", target_type="family", target_id=fam.id, detail=name,
              ip=client_ip(request))
    await db.commit()
    return redirect(f"/admin/families/{fam.id}", f"{name} added. Now add guardians and children.")


@router.get("/families/{fid}")
async def family_edit(request: Request, fid: str, me: Staff = Depends(admin_only), db: AsyncSession = Depends(get_db)):
    fam = await _family(db, fid)
    if not fam:
        return redirect("/admin/families", "Family not found.", True)
    s = await get_settings(db)
    link = family_url(s, fam) if base_url(s) else ""
    return await render(request, db, "admin/family_edit.html", {
        "fam": fam, "classes": await _classes(db), "link": link, "qr": _qr(link) if link else ""})


@router.post("/families/{fid}")
async def family_save(request: Request, fid: str, name: str = Form(""), authorized_pickups: str = Form(""),
                      notes: str = Form(""), is_active: str = Form(""), is_guest: str = Form(""),
                      me: Staff = Depends(admin_only),
                      db: AsyncSession = Depends(get_db)):
    fam = await _family(db, fid)
    if not fam:
        return redirect("/admin/families", "Family not found.", True)
    fam.name = _clean(name, 120) or fam.name
    fam.authorized_pickups = "\n".join(l.strip()[:120] for l in authorized_pickups.splitlines() if l.strip())[:3000]
    fam.notes = _clean(notes, 3000)
    fam.is_active = is_active == "on"
    fam.is_guest = is_guest == "on"
    log_event(db, actor=me.email, action="family.update", target_type="family", target_id=fam.id,
              detail=f"pickups: {fam.authorized_pickups.replace(chr(10), ', ')}", ip=client_ip(request))
    await db.commit()
    return redirect(f"/admin/families/{fid}", "Family saved.")


@router.post("/families/{fid}/guardians")
async def guardian_save(request: Request, fid: str, gid: str = Form(""), name: str = Form(""),
                        email: str = Form(""), phone: str = Form(""), notify_email: str = Form(""),
                        notify_sms: str = Form(""), action: str = Form("save"),
                        me: Staff = Depends(admin_only), db: AsyncSession = Depends(get_db)):
    fam = await _family(db, fid)
    if not fam:
        return redirect("/admin/families", "Family not found.", True)
    back = f"/admin/families/{fid}"
    g = next((x for x in fam.guardians if x.id == gid), None) if gid else None
    if action == "delete" and g:
        fam.guardians.remove(g)
        log_event(db, actor=me.email, action="guardian.delete", target_type="family", target_id=fid, detail=g.name)
        await db.commit()
        return redirect(back, f"{g.name} removed.")
    name, email = _clean(name, 120), _clean(email, 254).lower()
    if not name:
        return redirect(back, "Enter the guardian's name.", True)
    if email and not valid_email(email):
        return redirect(back, "That email address doesn't look right.", True)
    if phone.strip() and not normalize_phone(phone):
        return redirect(back, "Enter the phone as 10 digits, like 905-555-0123.", True)
    if not g:
        g = Guardian(family_id=fid)
        fam.guardians.append(g)
    g.name, g.email, g.phone = name, email, _clean(phone, 32)
    g.notify_email, g.notify_sms = notify_email == "on", notify_sms == "on"
    log_event(db, actor=me.email, action="guardian.save", target_type="family", target_id=fid, detail=name,
              ip=client_ip(request))
    await db.commit()
    return redirect(back, f"{name} saved.")


@router.post("/families/{fid}/children")
async def child_save(request: Request, fid: str, cid: str = Form(""), first_name: str = Form(""),
                     last_name: str = Form(""), class_id: str = Form(""), care_notes: str = Form(""),
                     is_active: str = Form("on"), action: str = Form("save"),
                     me: Staff = Depends(admin_only), db: AsyncSession = Depends(get_db)):
    fam = await _family(db, fid)
    if not fam:
        return redirect("/admin/families", "Family not found.", True)
    back = f"/admin/families/{fid}"
    c = next((x for x in fam.children if x.id == cid), None) if cid else None
    if action == "delete" and c:
        if await _still_here(db, [c.id]):
            return redirect(back, f"{c.first_name} is checked in right now. Release them before deleting.", True)
        name = c.full_name
        fam.children.remove(c)
        log_event(db, actor=me.email, action="child.delete", target_type="child", target_id=cid, detail=name,
                  ip=client_ip(request))
        await db.commit()
        return redirect(back, f"{name} deleted. Past attendance stays in the reports.")
    first = _clean(first_name, 80)
    if not first:
        return redirect(back, "Enter the child's first name.", True)
    classes = {x.id for x in await _classes(db, active_only=False)}
    if not c:
        c = Child(family_id=fid)
        fam.children.append(c)
    c.first_name, c.last_name = first, _clean(last_name, 80)
    c.class_id = class_id if class_id in classes else None
    c.care_notes = _clean(care_notes, 1000)
    c.is_active = is_active == "on"
    log_event(db, actor=me.email, action="child.save", target_type="family", target_id=fid, detail=c.full_name,
              ip=client_ip(request))
    await db.commit()
    return redirect(back, f"{first} saved.")


async def _still_here(db: AsyncSession, child_ids: list[str]) -> bool:
    """True if any of these children is checked in today and not yet picked up."""
    if not child_ids:
        return False
    s = await get_settings(db)
    recs = await records_for(db, child_ids, today(s))
    return any(not r.checked_out_at for r in recs.values())


@router.post("/families/{fid}/delete")
async def family_delete(request: Request, fid: str, me: Staff = Depends(admin_only), db: AsyncSession = Depends(get_db)):
    fam = await _family(db, fid)
    if not fam:
        return redirect("/admin/families", "Family not found.", True)
    if await _still_here(db, [c.id for c in fam.children]):
        return redirect(f"/admin/families/{fid}", "A child in this family is checked in right now. "
                                                  "Release them before deleting the family.", True)
    name = fam.name
    log_event(db, actor=me.email, action="family.delete", target_type="family", target_id=fid,
              detail=f"{name}: {', '.join(c.full_name for c in fam.children)}", ip=client_ip(request))
    await db.delete(fam)
    await db.commit()
    return redirect("/admin/families", f"{name} deleted. Past attendance stays in the reports.")


@router.post("/families/{fid}/link")
async def family_link(request: Request, fid: str, action: str = Form(""), me: Staff = Depends(admin_only),
                      db: AsyncSession = Depends(get_db)):
    fam = await _family(db, fid)
    if not fam:
        return redirect("/admin/families", "Family not found.", True)
    back = f"/admin/families/{fid}"
    s = await get_settings(db)
    if action == "regenerate":
        fam.link_version += 1
        log_event(db, actor=me.email, action="family.link_reset", target_type="family", target_id=fid,
                  ip=client_ip(request))
        await db.commit()
        return redirect(back, "New link created. The old link no longer works.")
    if action == "email":
        if not base_url(s):
            return redirect(back, "Set the public web address in Settings first.", True)
        link = family_url(s, fam)
        html = render_email("link.html", s=s, fam=fam, link=link)
        text = (f"Here is your private {s.program_name} check-in link for the {fam.name}:\n{link}\n\n"
                "Save it to your home screen. Don't share it outside your family.")
        to = [g.email for g in fam.guardians if g.email]
        sent = 0
        for addr in to:
            sent += await send_email([addr], f"Your {s.program_name} check-in link", html, text,
                                     from_name=s.church_name)
        log_event(db, actor=me.email, action="family.link_emailed", target_type="family", target_id=fid,
                  detail=f"{sent} sent", ip=client_ip(request))
        await db.commit()
        if not to:
            return redirect(back, "Add a guardian email first.", True)
        return redirect(back, f"Link emailed to {sent} of {len(to)} guardian(s)." if sent else
                        "The email didn't send. Check the email settings.", not sent)
    return redirect(back)


# ---------------- classes ----------------
async def _class_counts(db: AsyncSession) -> dict:
    return dict((await db.execute(select(Child.class_id, func.count()).where(Child.is_active.is_(True))
                                  .group_by(Child.class_id))).all())


@router.get("/classes")
async def classes(request: Request, me: Staff = Depends(admin_only), db: AsyncSession = Depends(get_db)):
    cls = await _classes(db, active_only=False)
    return await render(request, db, "admin/classes.html", {"classes": cls, "counts": await _class_counts(db)})


@router.post("/classes")
async def class_save(request: Request, cid: str = Form(""), name: str = Form(""), room: str = Form(""),
                     sort_order: int = Form(0), is_active: str = Form("on"), me: Staff = Depends(admin_only),
                     db: AsyncSession = Depends(get_db)):
    name = _clean(name, 80)
    back = f"/admin/classes/{cid}" if cid else "/admin/classes"
    if not name:
        return redirect(back, "Enter a class name.", True)
    c = await db.get(ClassGroup, cid) if cid else None
    if not c:
        c = ClassGroup()
        db.add(c)
    c.name, c.room, c.sort_order, c.is_active = name, _clean(room, 80), max(0, min(sort_order, 999)), is_active == "on"
    await db.flush()
    log_event(db, actor=me.email, action="class.save", target_type="class", target_id=c.id, detail=name,
              ip=client_ip(request))
    await db.commit()
    return redirect(f"/admin/classes/{c.id}", f"{name} saved.")


@router.get("/classes/{cid}")
async def class_detail(request: Request, cid: str, me: Staff = Depends(admin_only), db: AsyncSession = Depends(get_db)):
    c = await db.get(ClassGroup, cid)
    if not c:
        return redirect("/admin/classes", "Class not found.", True)
    kids = list((await db.execute(select(Child).options(selectinload(Child.family))
                                  .where(Child.class_id == cid).order_by(Child.first_name, Child.last_name))).scalars())
    fams = list((await db.execute(select(Family).where(Family.is_active.is_(True)).order_by(Family.name))).scalars())
    s = await get_settings(db)
    recs = await records_for(db, [k.id for k in kids], today(s))
    return await render(request, db, "admin/class_detail.html", {
        "c": c, "kids": kids, "families": fams, "recs": recs, "classes": await _classes(db)})


@router.post("/classes/{cid}/children")
async def class_add_child(request: Request, cid: str, first_name: str = Form(""), last_name: str = Form(""),
                          family_id: str = Form(""), new_family: str = Form(""), parent_name: str = Form(""),
                          parent_email: str = Form(""), parent_phone: str = Form(""), care_notes: str = Form(""),
                          me: Staff = Depends(admin_only), db: AsyncSession = Depends(get_db)):
    back = f"/admin/classes/{cid}"
    c = await db.get(ClassGroup, cid)
    if not c:
        return redirect("/admin/classes", "Class not found.", True)
    first, last = _clean(first_name, 80), _clean(last_name, 80)
    if not first:
        return redirect(back, "Enter the child's first name.", True)
    fam = await _family(db, family_id) if family_id else None
    if not fam:
        fam_name = _clean(new_family, 120) or (f"{last} family" if last else "")
        if not fam_name:
            return redirect(back, "Choose a family, or type a new family name.", True)
        email = _clean(parent_email, 254).lower()
        if email and not valid_email(email):
            return redirect(back, "That parent email doesn't look right.", True)
        if parent_phone.strip() and not normalize_phone(parent_phone):
            return redirect(back, "Enter the parent's phone as 10 digits, like 905-555-0123.", True)
        fam = Family(name=fam_name)
        db.add(fam)
        await db.flush()
        if _clean(parent_name, 120):
            db.add(Guardian(family_id=fam.id, name=_clean(parent_name, 120), email=email,
                            phone=_clean(parent_phone, 32), notify_email=bool(email)))
        log_event(db, actor=me.email, action="family.create", target_type="family", target_id=fam.id, detail=fam_name)
    child = Child(family_id=fam.id, first_name=first, last_name=last, class_id=cid, care_notes=_clean(care_notes, 1000))
    db.add(child)
    log_event(db, actor=me.email, action="child.save", target_type="family", target_id=fam.id,
              detail=f"{first} {last} added to {c.name}", ip=client_ip(request))
    await db.commit()
    return redirect(back, f"{first} added to {c.name}.")


@router.post("/classes/{cid}/move")
async def class_move_child(request: Request, cid: str, child_id: str = Form(""), to_class: str = Form(""),
                           me: Staff = Depends(admin_only), db: AsyncSession = Depends(get_db)):
    child = await db.get(Child, child_id)
    target = await db.get(ClassGroup, to_class) if to_class else None
    if not child or child.class_id != cid:
        return redirect(f"/admin/classes/{cid}", "Child not found in this class.", True)
    child.class_id = target.id if target else None
    log_event(db, actor=me.email, action="child.move", target_type="child", target_id=child.id,
              detail=f"{child.full_name} to {target.name if target else 'no class'}", ip=client_ip(request))
    await db.commit()
    return redirect(f"/admin/classes/{cid}", f"{child.first_name} moved to {target.name if target else 'no class'}.")


@router.post("/classes/{cid}/delete")
async def class_delete(request: Request, cid: str, me: Staff = Depends(admin_only), db: AsyncSession = Depends(get_db)):
    c = await db.get(ClassGroup, cid)
    if not c:
        return redirect("/admin/classes", "Class not found.", True)
    kids = list((await db.execute(select(Child).where(Child.class_id == cid))).scalars())
    for k in kids:
        k.class_id = None
    for r in (await db.execute(select(RosterEntry).where(RosterEntry.class_id == cid))).scalars():
        r.class_id = None
    name = c.name
    log_event(db, actor=me.email, action="class.delete", target_type="class", target_id=cid,
              detail=f"{name}; {len(kids)} children now unassigned", ip=client_ip(request))
    await db.delete(c)
    await db.commit()
    msg = f"{name} deleted." + (f" {len(kids)} children need a new class." if kids else "")
    return redirect("/admin/classes", msg)


# ---------------- staff ----------------
@router.get("/staff")
async def staff_list(request: Request, me: Staff = Depends(admin_only), db: AsyncSession = Depends(get_db)):
    people = list((await db.execute(select(Staff).order_by(Staff.role, Staff.name))).scalars())
    return await render(request, db, "admin/staff.html", {"people": people})


@router.post("/staff")
async def staff_save(request: Request, sid: str = Form(""), name: str = Form(""), email: str = Form(""),
                     phone: str = Form(""), role: str = Form("teacher"), can_login: str = Form(""),
                     password: str = Form(""), is_active: str = Form("on"), remind_by_email: str = Form(""),
                     me: Staff = Depends(admin_only), db: AsyncSession = Depends(get_db)):
    name, email = _clean(name, 120), _clean(email, 254).lower()
    if not name or not valid_email(email):
        return redirect("/admin/staff", "Enter a name and a valid email.", True)
    st = await db.get(Staff, sid) if sid else None
    creating = st is None
    if creating:
        st = Staff()
        db.add(st)
    if st.id == me.id and (role != "admin" or is_active != "on" or can_login != "on"):
        return redirect("/admin/staff", "You can't remove your own admin access or sign-in.", True)
    wants_login = can_login == "on"
    if password:
        problem = password_problem(password)
        if problem:
            return redirect("/admin/staff", problem, True)
        st.password_hash = hash_password(password)
        st.session_version = (st.session_version or 1) + 1
        st.failed_logins = 0
    if wants_login and not st.password_hash:
        return redirect("/admin/staff", "Set a password (8+ characters) to allow sign-in.", True)
    changed_priv = (not creating) and (st.role != role or st.can_login != wants_login)
    st.name, st.email, st.phone = name, email, _clean(phone, 32)
    st.role = "admin" if role == "admin" else "teacher"
    st.can_login, st.is_active, st.remind_by_email = wants_login, is_active == "on", remind_by_email == "on"
    if changed_priv or not st.is_active:
        st.session_version = (st.session_version or 1) + 1  # sign them out everywhere
    try:
        await db.flush()
    except IntegrityError:
        await db.rollback()
        return redirect("/admin/staff", "Someone already uses that email.", True)
    log_event(db, actor=me.email, action="staff.create" if creating else "staff.update", target_type="staff",
              target_id=st.id, detail=f"{email} role={st.role} login={st.can_login} active={st.is_active}",
              ip=client_ip(request))
    await db.commit()
    return redirect("/admin/staff", f"{name} saved.")


@router.post("/staff/{sid}/security")
async def staff_security(request: Request, sid: str, action: str = Form(""), me: Staff = Depends(admin_only),
                         db: AsyncSession = Depends(get_db)):
    st = await db.get(Staff, sid)
    if not st:
        return redirect("/admin/staff", "Not found.", True)
    if action == "unlock":
        st.locked_until, st.failed_logins = None, 0
        msg = f"{st.name} unlocked."
    elif action == "reset_mfa" and st.id != me.id:
        st.mfa_enabled, st.mfa_secret, st.mfa_backup_codes = False, None, ""
        st.session_version += 1
        msg = f"Two-step sign-in reset for {st.name}. They'll set it up again at next sign-in."
    else:
        return redirect("/admin/staff")
    log_event(db, actor=me.email, action=f"staff.{action}", target_type="staff", target_id=st.id, detail=st.email,
              ip=client_ip(request))
    await db.commit()
    return redirect("/admin/staff", msg)


