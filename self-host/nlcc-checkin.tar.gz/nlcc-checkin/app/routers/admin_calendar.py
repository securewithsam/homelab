"""Admin calendar: Sundays and special events, cancelled days, the teacher roster and reminder emails."""
import calendar as pycal
from datetime import date, timedelta

from fastapi import APIRouter, Depends, Form, Request
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.attendance import day_from, events_between, today
from app.audit import log_event
from app.auth import admin_only, client_ip, require_csrf
from app.database import get_db
from app.jobs import run_and_log, send_teacher_reminders
from app.models import Attendance, ClassGroup, RosterEntry, ServiceEvent, Staff
from app.settings_service import get_settings
from app.templating import redirect, render
from app.timeutil import valid_hhmm

router = APIRouter(prefix="/admin", dependencies=[Depends(require_csrf)])


def _parse_day(value: str) -> date | None:
    try:
        return date.fromisoformat(value)
    except ValueError:
        return None


@router.get("/roster")
async def roster_redirect(me: Staff = Depends(admin_only)):
    return redirect("/admin/calendar")


@router.get("/calendar")
async def month(request: Request, m: str = "", me: Staff = Depends(admin_only), db: AsyncSession = Depends(get_db)):
    s = await get_settings(db)
    t = today(s)
    try:
        y, mo = (int(x) for x in m.split("-"))
        first = date(y, mo, 1)
    except ValueError:
        first = date(t.year, t.month, 1)
    last = date(first.year, first.month, pycal.monthrange(first.year, first.month)[1])
    evs = await events_between(db, first, last)
    roster_counts = dict((await db.execute(
        select(RosterEntry.service_date, func.count()).where(RosterEntry.service_date >= first,
                                                             RosterEntry.service_date <= last)
        .group_by(RosterEntry.service_date))).all())
    att_counts = dict((await db.execute(
        select(Attendance.service_date, func.count()).where(Attendance.service_date >= first,
                                                            Attendance.service_date <= last)
        .group_by(Attendance.service_date))).all())
    weeks = pycal.Calendar(firstweekday=6).monthdatescalendar(first.year, first.month)
    cells = {}
    for week in weeks:
        for d in week:
            ev = evs.get(d) if first <= d <= last else None
            sd = day_from(s, d, ev)
            cells[d] = {"sd": sd, "ev": ev, "roster": roster_counts.get(d, 0), "kids": att_counts.get(d, 0)}
    prev_m = (first - timedelta(days=1)).replace(day=1)
    next_m = last + timedelta(days=1)
    agenda = [(d, c) for d, c in cells.items() if first <= d <= last and (c["sd"] or c["ev"] or c["roster"])]
    return await render(request, db, "admin/calendar.html", {
        "first": first, "weeks": weeks, "cells": cells, "today": t, "prev_m": prev_m, "next_m": next_m,
        "agenda": agenda})


@router.get("/calendar/go")
async def jump(d: str = "", me: Staff = Depends(admin_only)):
    day = _parse_day(d)
    return redirect(f"/admin/calendar/{day.isoformat()}" if day else "/admin/calendar")


@router.get("/calendar/{day}")
async def day_page(request: Request, day: str, me: Staff = Depends(admin_only), db: AsyncSession = Depends(get_db)):
    d = _parse_day(day)
    if not d:
        return redirect("/admin/calendar", "Pick a date on the calendar.", True)
    s = await get_settings(db)
    ev = (await events_between(db, d, d)).get(d)
    entries = list((await db.execute(
        select(RosterEntry).options(selectinload(RosterEntry.staff), selectinload(RosterEntry.class_group))
        .where(RosterEntry.service_date == d).order_by(RosterEntry.class_id))).scalars())
    teachers = list((await db.execute(select(Staff).where(Staff.is_active.is_(True)).order_by(Staff.name))).scalars())
    classes = list((await db.execute(select(ClassGroup).where(ClassGroup.is_active.is_(True))
                                     .order_by(ClassGroup.sort_order, ClassGroup.name))).scalars())
    kids = (await db.execute(select(func.count()).select_from(Attendance)
                             .where(Attendance.service_date == d))).scalar_one()
    return await render(request, db, "admin/day.html", {
        "d": d, "ev": ev, "sd": day_from(s, d, ev), "entries": entries, "teachers": teachers, "classes": classes,
        "kids": kids, "is_sunday": d.weekday() == 6, "today": today(s)})


@router.post("/calendar/{day}/event")
async def event_save(request: Request, day: str, action: str = Form("save"), name: str = Form(""),
                     start_time: str = Form(""), end_time: str = Form(""), me: Staff = Depends(admin_only),
                     db: AsyncSession = Depends(get_db)):
    d = _parse_day(day)
    if not d:
        return redirect("/admin/calendar")
    back = f"/admin/calendar/{d.isoformat()}"
    ev = (await events_between(db, d, d)).get(d)
    if action in ("delete", "restore"):
        if ev:
            log_event(db, actor=me.email, action="calendar.event_delete", detail=f"{d} {ev.name}", ip=client_ip(request))
            await db.delete(ev)
            await db.commit()
        return redirect(back, "Back to a regular Sunday." if action == "restore" else "Event removed.")
    if action == "cancel":
        if not ev:
            ev = ServiceEvent(event_date=d)
            db.add(ev)
        ev.cancelled, ev.name = True, _clean_name(name) or "No class"
        log_event(db, actor=me.email, action="calendar.cancel", detail=str(d), ip=client_ip(request))
        await db.commit()
        return redirect(back, "Class cancelled for this day. No reminders will be sent.")
    name = _clean_name(name)
    if not name:
        return redirect(back, "Give the event a name, for example VBS day 1.", True)
    if not (valid_hhmm(start_time) and valid_hhmm(end_time)) or end_time <= start_time:
        return redirect(back, "Enter a start time and a later end time.", True)
    if not ev:
        ev = ServiceEvent(event_date=d)
        db.add(ev)
    ev.name, ev.start_time, ev.end_time, ev.cancelled = name, start_time, end_time, False
    try:
        await db.flush()
    except IntegrityError:
        await db.rollback()
        return redirect(back, "Someone else just changed this day. Try again.", True)
    log_event(db, actor=me.email, action="calendar.event_save", detail=f"{d} {name} {start_time}-{end_time}",
              ip=client_ip(request))
    await db.commit()
    return redirect(back, f"{name} saved.")


def _clean_name(v: str) -> str:
    return (v or "").strip()[:120]


@router.post("/calendar/{day}/roster")
async def roster_change(request: Request, day: str, action: str = Form("add"), staff_id: str = Form(""),
                        class_id: str = Form(""), note: str = Form(""), entry_id: str = Form(""),
                        message: str = Form(""), me: Staff = Depends(admin_only), db: AsyncSession = Depends(get_db)):
    d = _parse_day(day)
    if not d:
        return redirect("/admin/calendar")
    back = f"/admin/calendar/{d.isoformat()}"
    s = await get_settings(db)
    note = note.strip()[:500]
    if action == "email_all":
        result = await run_and_log(db, me.email, "manual.teacher_reminder",
                                   send_teacher_reminders(db, s, d, message=message.strip()[:1000]))
        return redirect(back, result, "0 emails" in result)
    entry = await db.get(RosterEntry, entry_id) if entry_id else None
    if entry and entry.service_date != d:
        entry = None
    if action == "delete" and entry:
        log_event(db, actor=me.email, action="roster.delete", target_type="roster", target_id=entry.id, detail=str(d))
        await db.delete(entry)
        await db.commit()
        return redirect(back, "Removed from the roster.")
    if action in ("save", "save_email") and entry:
        entry.note = note
        if class_id != "keep":
            cls = await db.get(ClassGroup, class_id) if class_id else None
            entry.class_id = cls.id if cls else None
        await db.commit()
        if action == "save_email":
            result = await run_and_log(db, me.email, "manual.teacher_reminder",
                                       send_teacher_reminders(db, s, d, only_ids=[entry.id]))
            return redirect(back, result, "0 emails" in result)
        return redirect(back, "Saved.")
    if action == "add":
        st = await db.get(Staff, staff_id)
        if not st or not st.is_active:
            return redirect(back, "Pick a teacher.", True)
        cls = await db.get(ClassGroup, class_id) if class_id else None
        try:
            async with db.begin_nested():
                db.add(RosterEntry(service_date=d, staff_id=st.id, class_id=cls.id if cls else None, note=note))
        except IntegrityError:
            return redirect(back, f"{st.name} is already on the roster for this day.", True)
        log_event(db, actor=me.email, action="roster.add", target_type="staff", target_id=st.id,
                  detail=f"{d} {cls.name if cls else 'any class'}", ip=client_ip(request))
        await db.commit()
        return redirect(back, f"{st.name} added.")
    return redirect(back)
