"""Generic check-in station: one shared link (foyer tablet or a QR code at the door).

Families find their child by typing part of the name; first-time guests register and check in.
Only check-in happens here. Pickup stays with the family link or the teacher, so a shared device
can never release a child.
"""
import hmac
import secrets

from fastapi import APIRouter, BackgroundTasks, Depends, Form, HTTPException, Request
from fastapi.responses import JSONResponse
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.attendance import check_in, checkin_window, records_for, today
from app.audit import log_event
from app.auth import client_ip, rate_limited, require_csrf
from app.database import get_db
from app.jobs import family_url, notify_teachers_of_checkins
from app.models import AppSettings, Child, ClassGroup, Family, Guardian
from app.notify import normalize_phone, render_email, send_email, valid_email
from app.settings_service import base_url, get_settings
from app.templating import redirect, render

router = APIRouter(prefix="/checkin/{key}", dependencies=[Depends(require_csrf)])


def new_kiosk_token() -> str:
    return secrets.token_urlsafe(18)


async def station(key: str, request: Request, db: AsyncSession = Depends(get_db)) -> AppSettings:
    if rate_limited(f"kiosk:{client_ip(request)}", 90):
        raise HTTPException(status_code=429, detail="Too many requests. Wait a minute and try again.")
    s = await get_settings(db)
    if not s.kiosk_token or not hmac.compare_digest(key, s.kiosk_token):
        raise HTTPException(status_code=404)
    return s


def _label(c: Child) -> str:
    """First name and last initial only: enough for a parent to recognize, little for a stranger."""
    return f"{c.first_name} {c.last_name[:1]}.".strip() if c.last_name else c.first_name


async def _classes(db: AsyncSession) -> list[ClassGroup]:
    return list((await db.execute(select(ClassGroup).where(ClassGroup.is_active.is_(True))
                                  .order_by(ClassGroup.sort_order, ClassGroup.name))).scalars())


@router.get("")
async def home(request: Request, key: str, s: AppSettings = Depends(station), db: AsyncSession = Depends(get_db)):
    is_open, msg = await checkin_window(db, s)
    return await render(request, db, "kiosk/home.html", {"key": key, "is_open": is_open, "closed_msg": msg})


@router.get("/search.json")
async def search(key: str, q: str = "", s: AppSettings = Depends(station), db: AsyncSession = Depends(get_db)):
    q = q.strip()[:40]
    if len(q) < 3:  # three letters minimum so the list can't be browsed
        return JSONResponse({"results": []})
    like = f"%{q}%"
    full = Child.first_name + " " + Child.last_name
    rows = await db.execute(select(Child).options(selectinload(Child.class_group))
                            .join(Family, Family.id == Child.family_id)
                            .where(Child.is_active.is_(True), Family.is_active.is_(True),
                                   Child.first_name.ilike(like) | Child.last_name.ilike(like) | full.ilike(like))
                            .order_by(Child.first_name).limit(8))
    kids = list(rows.scalars())
    recs = await records_for(db, [c.id for c in kids], today(s))
    return JSONResponse({"results": [{"id": c.id, "name": _label(c), "first": c.first_name,
                                      "cls": c.class_group.name if c.class_group else "",
                                      "status": "Checked in" if c.id in recs else ""} for c in kids]})


@router.post("/in")
async def kiosk_checkin(request: Request, background: BackgroundTasks, key: str, child_id: str = Form(""),
                        s: AppSettings = Depends(station), db: AsyncSession = Depends(get_db)):
    is_open, msg = await checkin_window(db, s)
    if not is_open:
        return redirect(f"/checkin/{key}", msg, True)
    child = (await db.execute(select(Child).options(selectinload(Child.class_group))
                              .where(Child.id == child_id, Child.is_active.is_(True)))).scalar_one_or_none()
    if not child:
        return redirect(f"/checkin/{key}", "Choose your child from the list.", True)
    already = (await records_for(db, [child.id], today(s))).get(child.id)
    att = already or await check_in(db, child, today(s), "Check-in station")
    if not already:
        log_event(db, actor="check-in station", action="attendance.checkin", target_type="child",
                  target_id=child.id, detail=f"{child.full_name} at check-in station", ip=client_ip(request))
    await db.commit()
    if att and not already:
        background.add_task(notify_teachers_of_checkins, [att.id])
    return await render(request, db, "kiosk/done.html", {
        "key": key, "first": child.first_name, "cls": child.class_group, "already": bool(already), "guest": False})


@router.get("/new")
async def guest_form(request: Request, key: str, s: AppSettings = Depends(station), db: AsyncSession = Depends(get_db)):
    if not s.kiosk_guests_on:
        return redirect(f"/checkin/{key}", "Please see a greeter to register a new child.", True)
    return await render(request, db, "kiosk/guest.html", {"key": key, "classes": await _classes(db), "f": {}})


@router.post("/new")
async def guest_save(request: Request, background: BackgroundTasks, key: str, s: AppSettings = Depends(station),
                     db: AsyncSession = Depends(get_db)):
    if not s.kiosk_guests_on:
        return redirect(f"/checkin/{key}", "Please see a greeter to register a new child.", True)
    form = await request.form()
    f = {k: str(form.get(k, "")).strip() for k in
         ("first_name", "last_name", "class_id", "parent_name", "parent_phone", "parent_email", "care_notes")}
    f["agree"] = form.get("agree") == "on"
    classes = await _classes(db)
    errors = []
    if not f["first_name"] or not f["last_name"]:
        errors.append("Enter your child's first and last name.")
    if f["class_id"] not in {c.id for c in classes}:
        errors.append("Choose a class.")
    if not f["parent_name"]:
        errors.append("Enter your name. You'll be on the pickup list.")
    if not f["parent_phone"] or not normalize_phone(f["parent_phone"]):
        errors.append("Enter a mobile number so the teacher can reach you, like 905-555-0123.")
    if f["parent_email"] and not valid_email(f["parent_email"]):
        errors.append("That email address doesn't look right.")
    if not f["agree"]:
        errors.append("Confirm you're the child's parent or guardian.")
    is_open, msg = await checkin_window(db, s)
    if not is_open:
        errors.insert(0, msg)
    if errors:
        return await render(request, db, "kiosk/guest.html",
                            {"key": key, "classes": classes, "f": f, "errors": errors}, status_code=400)
    if rate_limited(f"guest:{client_ip(request)}", 12, 3600):
        raise HTTPException(status_code=429, detail="Too many new registrations from this device. See a greeter.")
    first, last = f["first_name"][:80], f["last_name"][:80]
    fam = Family(name=f"{last} family"[:120], is_guest=True,
                 notes=f"Registered as a guest at the check-in station on {today(s).isoformat()}.")
    db.add(fam)
    await db.flush()
    email = f["parent_email"].lower()[:254]
    db.add(Guardian(family_id=fam.id, name=f["parent_name"][:120], email=email, phone=f["parent_phone"][:32],
                    notify_email=bool(email)))
    child = Child(family_id=fam.id, first_name=first, last_name=last, class_id=f["class_id"],
                  care_notes=f["care_notes"][:1000])
    db.add(child)
    await db.flush()
    child = (await db.execute(select(Child).options(selectinload(Child.class_group))
                              .where(Child.id == child.id))).scalar_one()
    att = await check_in(db, child, today(s), f"Guest registration ({f['parent_name'][:60]})")
    log_event(db, actor="check-in station", action="family.guest", target_type="family", target_id=fam.id,
              detail=f"{child.full_name}, parent {f['parent_name']}", ip=client_ip(request))
    await db.commit()
    if att:
        background.add_task(notify_teachers_of_checkins, [att.id])
    if email and base_url(s):
        fam = (await db.execute(select(Family).where(Family.id == fam.id))).scalar_one()
        background.add_task(_email_guest_link, s, fam, email)
    return await render(request, db, "kiosk/done.html", {
        "key": key, "first": first, "cls": child.class_group, "already": False, "guest": True,
        "parent": f["parent_name"], "emailed": bool(email)})


async def _email_guest_link(s: AppSettings, fam: Family, email: str) -> None:
    link = family_url(s, fam)
    html = render_email("link.html", s=s, fam=fam, link=link)
    text = (f"Welcome! Here is your private {s.program_name} link for the {fam.name}:\n{link}\n\n"
            "Use it to check your children in and out next time.")
    await send_email([email], f"Welcome to {s.program_name}", html, text, from_name=s.church_name)
