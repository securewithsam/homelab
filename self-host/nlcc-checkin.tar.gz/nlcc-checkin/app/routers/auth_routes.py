"""Staff sign-in (password, then TOTP when enabled) and sign-out."""
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, Form, Request
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.audit import log_event
from app.auth import (MFA_COOKIE, SESSION_COOKIE, client_ip, is_locked, make_mfa_pending,
                      make_session, rate_limited, read_mfa_pending, read_session, register_failure, require_csrf,
                      set_cookie, use_backup_code, verify_password, verify_totp)
from app.config import SESSION_MAX_AGE
from app.database import get_db
from app.models import Staff
from app.templating import redirect, render

router = APIRouter(dependencies=[Depends(require_csrf)])
GENERIC = "That email and password don't match an active account."


def _landing(staff: Staff) -> str:
    return "/admin" if staff.is_admin else "/teacher"


def _sign_in(request: Request, staff: Staff):
    staff.failed_logins = 0
    staff.locked_until = None
    staff.last_login = datetime.now(timezone.utc)
    resp = redirect(_landing(staff))
    set_cookie(resp, SESSION_COOKIE, make_session(staff), SESSION_MAX_AGE)
    resp.delete_cookie(MFA_COOKIE, path="/")
    return resp


@router.get("/login")
async def login_page(request: Request, db: AsyncSession = Depends(get_db)):
    data = read_session(request.cookies.get(SESSION_COOKIE))
    if data:
        staff = await db.get(Staff, data.get("uid"))
        if staff and staff.can_login and staff.is_active:
            return redirect(_landing(staff))
    return await render(request, db, "auth/login.html")


@router.post("/login")
async def login(request: Request, email: str = Form(""), password: str = Form(""),
                db: AsyncSession = Depends(get_db)):
    ip = client_ip(request)
    email = email.strip().lower()[:254]
    if rate_limited(f"login:{ip}", 20):
        return await render(request, db, "auth/login.html", {"error": "Too many attempts. Wait a minute and try again.",
                                                             "email": email}, status_code=429)
    staff = (await db.execute(select(Staff).where(func.lower(Staff.email) == email))).scalar_one_or_none()
    if not staff or not staff.can_login or not staff.is_active:
        verify_password(password, None)
        log_event(db, actor=email or "unknown", action="auth.login_fail", detail="unknown or disabled", ip=ip)
        await db.commit()
        return await render(request, db, "auth/login.html", {"error": GENERIC, "email": email}, status_code=401)
    if is_locked(staff):
        log_event(db, actor=staff.email, action="auth.login_locked", target_type="staff", target_id=staff.id, ip=ip)
        await db.commit()
        return await render(request, db, "auth/login.html",
                            {"error": "This account is locked for 15 minutes after too many attempts. "
                                      "An administrator can unlock it sooner.", "email": email}, status_code=423)
    if not verify_password(password, staff.password_hash):
        locked = register_failure(staff)
        log_event(db, actor=staff.email, action="auth.lockout" if locked else "auth.login_fail",
                  target_type="staff", target_id=staff.id, ip=ip)
        await db.commit()
        return await render(request, db, "auth/login.html", {"error": GENERIC, "email": email}, status_code=401)
    if staff.mfa_enabled:
        resp = redirect("/login/mfa")
        set_cookie(resp, MFA_COOKIE, make_mfa_pending(staff), 300)
        return resp
    log_event(db, actor=staff.email, action="auth.login", target_type="staff", target_id=staff.id, ip=ip)
    resp = _sign_in(request, staff)
    await db.commit()
    return resp


@router.get("/login/mfa")
async def mfa_page(request: Request, db: AsyncSession = Depends(get_db)):
    if not read_mfa_pending(request.cookies.get(MFA_COOKIE)):
        return redirect("/login", "Your sign-in step expired. Enter your password again.", True)
    return await render(request, db, "auth/mfa.html")


@router.post("/login/mfa")
async def mfa_verify(request: Request, code: str = Form(""), db: AsyncSession = Depends(get_db)):
    ip = client_ip(request)
    pending = read_mfa_pending(request.cookies.get(MFA_COOKIE))
    if not pending:
        return redirect("/login", "Your sign-in step expired. Enter your password again.", True)
    if rate_limited(f"mfa:{ip}", 10):
        return await render(request, db, "auth/mfa.html", {"error": "Too many attempts. Wait a minute."}, 429)
    staff = await db.get(Staff, pending["uid"])
    if not staff or staff.session_version != pending["sv"] or not staff.is_active or is_locked(staff):
        return redirect("/login", "Sign in again.", True)
    code = code.strip()
    ok = verify_totp(staff.mfa_secret, code) or (len(code.replace("-", "")) == 8 and use_backup_code(staff, code))
    if not ok:
        locked = register_failure(staff)
        log_event(db, actor=staff.email, action="auth.lockout" if locked else "auth.mfa_fail",
                  target_type="staff", target_id=staff.id, ip=ip)
        await db.commit()
        if locked:
            return redirect("/login", "Too many wrong codes. The account is locked for 15 minutes.", True)
        return await render(request, db, "auth/mfa.html", {"error": "That code didn't work. Try the newest code."}, 401)
    log_event(db, actor=staff.email, action="auth.login", target_type="staff", target_id=staff.id,
              detail="with MFA", ip=ip)
    resp = _sign_in(request, staff)
    await db.commit()
    return resp


@router.post("/logout")
async def logout(request: Request, db: AsyncSession = Depends(get_db)):
    data = read_session(request.cookies.get(SESSION_COOKIE))
    if data:
        staff = await db.get(Staff, data.get("uid"))
        if staff:
            log_event(db, actor=staff.email, action="auth.logout", target_type="staff", target_id=staff.id,
                      ip=client_ip(request))
            await db.commit()
    resp = redirect("/login", "You're signed out.")
    resp.delete_cookie(SESSION_COOKIE, path="/")
    return resp
