"""Staff profile: display preferences, password change, two-step sign-in (TOTP + backup codes)."""
from fastapi import APIRouter, Depends, Form, Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.audit import log_event
from app.auth import (SESSION_COOKIE, client_ip, hash_password, make_session, mfa_qr_data_uri, new_backup_codes,
                      new_mfa_secret, password_problem, require_csrf, set_cookie, staff_any, verify_password,
                      verify_totp)
from app.config import COOKIE_SECURE, REQUIRE_ADMIN_MFA, SESSION_MAX_AGE
from app.database import get_db
from app.models import Staff
from app.settings_service import get_settings
from app.templating import FONT_SIZES, redirect, render

router = APIRouter(dependencies=[Depends(require_csrf)])


@router.get("/profile")
async def profile(request: Request, me: Staff = Depends(staff_any), db: AsyncSession = Depends(get_db)):
    return await render(request, db, "profile.html", {
        "mfa_required": REQUIRE_ADMIN_MFA and me.is_admin and not me.mfa_enabled, "mfa_forced": REQUIRE_ADMIN_MFA})


@router.post("/profile/display")
async def profile_display(theme: str = Form(""), font_size: str = Form(""), back: str = Form("/profile"),
                          me: Staff = Depends(staff_any), db: AsyncSession = Depends(get_db)):
    if theme in ("dark", "light"):
        me.theme = theme
    if font_size in FONT_SIZES:
        me.font_size = font_size
    await db.commit()
    return redirect(back if back.startswith("/") and not back.startswith("//") else "/profile")


@router.post("/display")
async def anon_display(theme: str = Form(""), font_size: str = Form(""), back: str = Form("/")):
    resp = redirect(back if back.startswith("/") and not back.startswith("//") else "/")
    if theme in ("dark", "light"):
        resp.set_cookie("nlcc_theme", theme, max_age=31536000, httponly=True, secure=COOKIE_SECURE, samesite="lax")
    if font_size in FONT_SIZES:
        resp.set_cookie("nlcc_font", font_size, max_age=31536000, httponly=True, secure=COOKIE_SECURE, samesite="lax")
    return resp


@router.post("/profile/password")
async def change_password(request: Request, current: str = Form(""), new: str = Form(""), confirm: str = Form(""),
                          me: Staff = Depends(staff_any), db: AsyncSession = Depends(get_db)):
    if not verify_password(current, me.password_hash):
        return redirect("/profile", "Your current password is wrong.", True)
    if new != confirm:
        return redirect("/profile", "The new passwords don't match.", True)
    problem = password_problem(new)
    if problem:
        return redirect("/profile", problem, True)
    me.password_hash = hash_password(new)
    me.session_version += 1  # signs out every other device
    log_event(db, actor=me.email, action="password.change", target_type="staff", target_id=me.id,
              ip=client_ip(request))
    await db.commit()
    request.state.refresh_session = None
    resp = redirect("/profile", "Password changed. Other devices are signed out.")
    set_cookie(resp, SESSION_COOKIE, make_session(me), SESSION_MAX_AGE)
    return resp


@router.post("/profile/mfa/start")
async def mfa_start(request: Request, me: Staff = Depends(staff_any), db: AsyncSession = Depends(get_db)):
    if me.mfa_enabled:
        return redirect("/profile")
    s = await get_settings(db)
    me.mfa_secret = new_mfa_secret()
    await db.commit()
    return await render(request, db, "mfa_setup.html", {
        "qr": mfa_qr_data_uri(me.mfa_secret, me.email, f"{s.church_name} check-in"), "secret": me.mfa_secret})


@router.post("/profile/mfa/confirm")
async def mfa_confirm(request: Request, code: str = Form(""), me: Staff = Depends(staff_any),
                      db: AsyncSession = Depends(get_db)):
    if me.mfa_enabled or not me.mfa_secret:
        return redirect("/profile")
    if not verify_totp(me.mfa_secret, code):
        s = await get_settings(db)
        return await render(request, db, "mfa_setup.html", {
            "qr": mfa_qr_data_uri(me.mfa_secret, me.email, f"{s.church_name} check-in"), "secret": me.mfa_secret,
            "error": "That code didn't match. Use the newest 6-digit code from your app."})
    codes, hashed = new_backup_codes()
    me.mfa_enabled, me.mfa_backup_codes = True, hashed
    me.session_version += 1
    log_event(db, actor=me.email, action="mfa.enable", target_type="staff", target_id=me.id, ip=client_ip(request))
    await db.commit()
    request.state.refresh_session = None
    resp = await render(request, db, "mfa_codes.html", {"codes": [f"{c[:4]}-{c[4:]}" for c in codes]})
    set_cookie(resp, SESSION_COOKIE, make_session(me), SESSION_MAX_AGE)
    return resp


@router.post("/profile/mfa/disable")
async def mfa_disable(request: Request, password: str = Form(""), code: str = Form(""),
                      me: Staff = Depends(staff_any), db: AsyncSession = Depends(get_db)):
    if me.is_admin and REQUIRE_ADMIN_MFA:
        return redirect("/profile", "Administrators must keep two-step sign-in on.", True)
    if not verify_password(password, me.password_hash) or not verify_totp(me.mfa_secret, code):
        return redirect("/profile", "Password or code is wrong.", True)
    me.mfa_enabled, me.mfa_secret, me.mfa_backup_codes = False, None, ""
    log_event(db, actor=me.email, action="mfa.disable", target_type="staff", target_id=me.id, ip=client_ip(request))
    await db.commit()
    return redirect("/profile", "Two-step sign-in turned off.")
