"""Parent-facing pages reached by the family's private link: check in, pick up, notification choices."""
from datetime import datetime, timezone

from fastapi import APIRouter, BackgroundTasks, Depends, Form, HTTPException, Request
from fastapi.responses import JSONResponse
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.attendance import check_in, checkin_window, records_for, request_pickup, today
from app.audit import log_event
from app.auth import client_ip, rate_limited, read_family_token, require_csrf
from app.config import sms_configured
from app.database import get_db
from app.jobs import notify_teachers_of_checkins
from app.models import Child, Family
from app.settings_service import get_settings
from app.templating import FONT_SIZES, redirect, render

router = APIRouter(prefix="/f/{token}", dependencies=[Depends(require_csrf)])


async def load_family(token: str, request: Request, db: AsyncSession = Depends(get_db)) -> Family:
    if rate_limited(f"family:{client_ip(request)}", 120):
        raise HTTPException(status_code=429, detail="Too many requests. Wait a minute and try again.")
    data = read_family_token(token)
    if not data:
        raise HTTPException(status_code=404)
    fam = (await db.execute(
        select(Family).options(selectinload(Family.guardians),
                               selectinload(Family.children).selectinload(Child.class_group))
        .where(Family.id == data.get("f")))).scalar_one_or_none()
    if not fam or not fam.is_active or fam.link_version != data.get("v"):
        raise HTTPException(status_code=404)
    return fam


def _age(dt: datetime) -> float:
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return (datetime.now(timezone.utc) - dt).total_seconds()


def _kids(fam: Family) -> list[Child]:
    return [c for c in fam.children if c.is_active]


@router.get("")
async def family_home(request: Request, token: str, fam: Family = Depends(load_family),
                      db: AsyncSession = Depends(get_db)):
    s = await get_settings(db)
    kids = _kids(fam)
    recs = await records_for(db, [c.id for c in kids], today(s))
    is_open, closed_msg = await checkin_window(db, s)
    waiting = [c for c in kids if c.id not in recs]
    return await render(request, db, "family/home.html", {
        "fam": fam, "kids": kids, "recs": recs, "is_open": is_open, "closed_msg": closed_msg,
        "waiting": waiting, "token": token, "pickups": fam.pickup_names(), "day": today(s),
        "poll": any(r.status == "pickup" for r in recs.values()),
        "fresh": {cid for cid, r in recs.items() if r.status == "in" and _age(r.checked_in_at) < 20},
    }, theme=fam.theme, font_size=fam.font_size)


@router.post("/checkin")
async def family_checkin(request: Request, background: BackgroundTasks, token: str, child_id: str = Form("all"),
                         fam: Family = Depends(load_family), db: AsyncSession = Depends(get_db)):
    s = await get_settings(db)
    is_open, msg = await checkin_window(db, s)
    if not is_open:
        return redirect(f"/f/{token}", msg, True)
    kids = _kids(fam)
    targets = kids if child_id == "all" else [c for c in kids if c.id == child_id]
    if not targets:
        return redirect(f"/f/{token}", "Choose a child to check in.", True)
    d = today(s)
    already = await records_for(db, [c.id for c in targets], d)
    names, new_ids = [], []
    for child in targets:
        if child.id in already:
            continue
        att = await check_in(db, child, d, f"Parent link ({fam.name})")
        if att:
            names.append(child.first_name)
            new_ids.append(att.id)
            log_event(db, actor=f"family:{fam.name}", action="attendance.checkin", target_type="child",
                      target_id=child.id, detail=f"{child.full_name} via family link", ip=client_ip(request))
    await db.commit()
    background.add_task(notify_teachers_of_checkins, new_ids)
    who = " and ".join(names[-2:]) if len(names) <= 2 else ", ".join(names[:-1]) + " and " + names[-1]
    return redirect(f"/f/{token}", f"{who} checked in." if names else "Already checked in.")


@router.post("/checkout")
async def family_checkout(request: Request, token: str, child_id: str = Form(""), person: str = Form(""),
                          fam: Family = Depends(load_family), db: AsyncSession = Depends(get_db)):
    s = await get_settings(db)
    child = next((c for c in _kids(fam) if c.id == child_id), None)
    if not child:
        return redirect(f"/f/{token}", "Choose a child to check out.", True)
    if person not in fam.pickup_names():
        return redirect(f"/f/{token}", "Choose who is picking up from the list. The church office can add names.",
                        True)
    att = (await records_for(db, [child.id], today(s))).get(child.id)
    if not att or att.checked_out_at:
        return redirect(f"/f/{token}", f"{child.first_name} isn't checked in right now.", True)
    request_pickup(att, s, person, f"Parent link ({fam.name})")
    log_event(db, actor=f"family:{fam.name}", action="attendance.pickup_request", target_type="child",
              target_id=child.id, detail=f"{child.full_name}, pickup by {person}", ip=client_ip(request))
    await db.commit()
    if s.require_teacher_release:
        return redirect(f"/f/{token}", f"Show code {att.pickup_code} to the teacher to pick up {child.first_name}.")
    return redirect(f"/f/{token}", f"{child.first_name} checked out. See you next week.")


@router.get("/status.json")
async def family_status(token: str, fam: Family = Depends(load_family), db: AsyncSession = Depends(get_db)):
    s = await get_settings(db)
    recs = await records_for(db, [c.id for c in _kids(fam)], today(s))
    return JSONResponse({"v": "|".join(sorted(f"{k}:{r.status}" for k, r in recs.items()))})


@router.get("/notifications")
async def notif_page(request: Request, token: str, fam: Family = Depends(load_family),
                     db: AsyncSession = Depends(get_db)):
    s = await get_settings(db)
    return await render(request, db, "family/notifications.html", {
        "fam": fam, "token": token, "sms_on": s.sms_enabled and sms_configured()},
        theme=fam.theme, font_size=fam.font_size)


@router.post("/notifications")
async def notif_save(request: Request, token: str, fam: Family = Depends(load_family),
                     db: AsyncSession = Depends(get_db)):
    form = await request.form()
    for g in fam.guardians:
        g.notify_email = form.get(f"email_{g.id}") == "on"
        g.notify_sms = form.get(f"sms_{g.id}") == "on"
    log_event(db, actor=f"family:{fam.name}", action="family.notifications", target_type="family",
              target_id=fam.id, ip=client_ip(request))
    await db.commit()
    return redirect(f"/f/{token}/notifications", "Notification choices saved.")


@router.post("/display")
async def display_prefs(token: str, theme: str = Form(""), font_size: str = Form(""), back: str = Form(""),
                        fam: Family = Depends(load_family), db: AsyncSession = Depends(get_db)):
    if theme in ("dark", "light"):
        fam.theme = theme
    if font_size in FONT_SIZES:
        fam.font_size = font_size
    await db.commit()
    return redirect(f"/f/{token}/notifications" if back == "notifications" else f"/f/{token}")
