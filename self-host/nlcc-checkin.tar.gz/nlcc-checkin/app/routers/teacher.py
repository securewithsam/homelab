"""Teacher class board: who's here, pickup requests with code verification, walk-in check-in."""
import hmac

from fastapi import APIRouter, BackgroundTasks, Depends, Form, Request
from fastapi.responses import JSONResponse
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.attendance import check_in, day_records, records_for, release, today
from app.audit import log_event
from app.auth import client_ip, rate_limited, require_csrf, staff_any
from app.database import get_db
from app.jobs import notify_teachers_of_checkins
from app.models import Attendance, Child, ClassGroup, Family, RosterEntry, Staff
from app.settings_service import get_settings
from app.templating import redirect, render

router = APIRouter(prefix="/teacher", dependencies=[Depends(require_csrf)])


async def _classes(db: AsyncSession) -> list[ClassGroup]:
    rows = await db.execute(select(ClassGroup).where(ClassGroup.is_active.is_(True))
                            .order_by(ClassGroup.sort_order, ClassGroup.name))
    return list(rows.scalars())


async def _search(db: AsyncSession, q: str, d) -> list[Child]:
    """Active children matching any part of the name who aren't checked in yet today."""
    q = (q or "").strip()[:60]
    if len(q) < 2:
        return []
    like = f"%{q}%"
    full = Child.first_name + " " + Child.last_name
    rows = await db.execute(select(Child).options(selectinload(Child.class_group))
                            .where(Child.is_active.is_(True),
                                   Child.first_name.ilike(like) | Child.last_name.ilike(like) | full.ilike(like))
                            .order_by(Child.first_name, Child.last_name).limit(15))
    found = list(rows.scalars())
    done = await records_for(db, [c.id for c in found], d)
    return [c for c in found if c.id not in done]


@router.get("/search.json")
async def search_json(q: str = "", staff: Staff = Depends(staff_any), db: AsyncSession = Depends(get_db)):
    s = await get_settings(db)
    kids = await _search(db, q, today(s))
    return JSONResponse({"results": [{"id": c.id, "name": c.full_name, "first": c.first_name,
                                      "cls": c.class_group.name if c.class_group else "No class"} for c in kids]})


@router.get("")
async def board(request: Request, cls: str = "", q: str = "", staff: Staff = Depends(staff_any),
                db: AsyncSession = Depends(get_db)):
    s = await get_settings(db)
    d = today(s)
    classes = await _classes(db)
    my_roster = (await db.execute(select(RosterEntry).where(RosterEntry.service_date == d,
                                                            RosterEntry.staff_id == staff.id))).scalars().first()
    if cls == "" and my_roster and my_roster.class_id and "cls" not in request.query_params:
        cls = my_roster.class_id
    selected = next((c for c in classes if c.id == cls), None)
    recs = [a for a in await day_records(db, d) if a.child]  # skip children deleted today
    if selected:
        recs = [a for a in recs if a.class_name == selected.name]
    pickups = [a for a in recs if a.status == "pickup"]
    here = [a for a in recs if a.status == "in"]
    gone = [a for a in recs if a.status == "out"]
    q = q.strip()[:60]
    results = await _search(db, q, d)
    roster = (await db.execute(select(RosterEntry).options(selectinload(RosterEntry.staff),
                                                           selectinload(RosterEntry.class_group))
                               .where(RosterEntry.service_date == d))).scalars().all()
    return await render(request, db, "teacher/board.html", {
        "classes": classes, "selected": selected, "cls": cls, "pickups": pickups, "here": here, "gone": gone,
        "q": q, "results": results, "roster": roster, "day": d,
    })


@router.get("/board.json")
async def board_version(staff: Staff = Depends(staff_any), db: AsyncSession = Depends(get_db)):
    s = await get_settings(db)
    recs = await day_records(db, today(s))
    return JSONResponse({"v": "|".join(sorted(f"{a.id}:{a.status}" for a in recs))})


def _back(cls: str) -> str:
    return f"/teacher?cls={cls}" if cls else "/teacher?cls="


async def _att(db: AsyncSession, att_id: str, d) -> Attendance | None:
    att = (await db.execute(select(Attendance).options(selectinload(Attendance.child).selectinload(Child.family)
                                                       .selectinload(Family.guardians))
                            .where(Attendance.id == att_id))).scalar_one_or_none()
    return att if att and att.child and att.service_date == d else None


@router.post("/release")
async def release_with_code(request: Request, att_id: str = Form(""), code: str = Form(""), cls: str = Form(""),
                            staff: Staff = Depends(staff_any), db: AsyncSession = Depends(get_db)):
    s = await get_settings(db)
    att = await _att(db, att_id, today(s))
    if not att or att.status != "pickup":
        return redirect(_back(cls), "That pickup is no longer waiting.", True)
    if rate_limited(f"code:{att.id}", 5, 600):
        return redirect(_back(cls), "Too many wrong codes for this child. Use the manual release and check ID.", True)
    if not hmac.compare_digest(code.strip(), att.pickup_code or "-"):
        log_event(db, actor=staff.email, action="attendance.code_fail", target_type="child",
                  target_id=att.child_id, detail=att.child.full_name, ip=client_ip(request))
        await db.commit()
        return redirect(_back(cls), f"That code doesn't match {att.child.first_name}'s pickup. Ask to see the "
                                    f"code on the parent's phone.", True)
    release(att, staff.name, True)
    log_event(db, actor=staff.email, action="attendance.release", target_type="child", target_id=att.child_id,
              detail=f"{att.child.full_name} released to {att.pickup_person} (code verified)", ip=client_ip(request))
    await db.commit()
    return redirect(_back(cls), f"{att.child.first_name} released to {att.pickup_person}.")


@router.post("/release-manual")
async def release_manual(request: Request, att_id: str = Form(""), person: str = Form(""), cls: str = Form(""),
                         staff: Staff = Depends(staff_any), db: AsyncSession = Depends(get_db)):
    s = await get_settings(db)
    att = await _att(db, att_id, today(s))
    if not att or att.status == "out":
        return redirect(_back(cls), "That child is already checked out.", True)
    if person not in att.child.family.pickup_names():
        return redirect(_back(cls), "Only people on the family's pickup list can be chosen. "
                                    "Contact the family before releasing to anyone else.", True)
    release(att, staff.name, False, person)
    log_event(db, actor=staff.email, action="attendance.release_manual", target_type="child",
              target_id=att.child_id, detail=f"{att.child.full_name} released to {person} without code",
              ip=client_ip(request))
    await db.commit()
    return redirect(_back(cls), f"{att.child.first_name} released to {person}. Recorded as released without code.")


@router.post("/checkin")
async def staff_checkin(request: Request, background: BackgroundTasks, child_id: str = Form(""), cls: str = Form(""),
                        staff: Staff = Depends(staff_any), db: AsyncSession = Depends(get_db)):
    s = await get_settings(db)
    child = (await db.execute(select(Child).options(selectinload(Child.class_group))
                              .where(Child.id == child_id, Child.is_active.is_(True)))).scalar_one_or_none()
    if not child:
        return redirect(_back(cls), "Child not found.", True)
    att = await check_in(db, child, today(s), f"Staff: {staff.name}")
    log_event(db, actor=staff.email, action="attendance.checkin", target_type="child", target_id=child.id,
              detail=f"{child.full_name} by staff", ip=client_ip(request))
    await db.commit()
    if att:
        background.add_task(notify_teachers_of_checkins, [att.id])
    return redirect(_back(cls), f"{child.first_name} checked in.")


@router.post("/undo")
async def undo_checkin(request: Request, att_id: str = Form(""), cls: str = Form(""),
                       staff: Staff = Depends(staff_any), db: AsyncSession = Depends(get_db)):
    s = await get_settings(db)
    att = await _att(db, att_id, today(s))
    if not att or att.status != "in":
        return redirect(_back(cls), "Only a check-in with no pickup yet can be removed.", True)
    name = att.child.full_name
    log_event(db, actor=staff.email, action="attendance.undo", target_type="child", target_id=att.child_id,
              detail=f"Removed check-in for {name} (was by {att.checked_in_by})", ip=client_ip(request))
    await db.delete(att)
    await db.commit()
    return redirect(_back(cls), f"Check-in removed for {name}.")
