"""Admin: live dashboard, reports, notifications on demand, settings & branding, audit log."""
import csv
import io
import os
import re
import uuid
from datetime import date, timedelta

from fastapi import APIRouter, Depends, File, Form, Request, UploadFile
from fastapi.responses import Response
from PIL import Image, UnidentifiedImageError
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app import config
from app.attendance import day_records, next_service_day, service_day, today
from app.audit import log_event
from app.auth import admin_only, client_ip, require_csrf
from app.database import get_db
from app.jobs import (run_and_log, send_checkin_reminders, send_checkout_reminders, send_monthly_report,
                      send_teacher_reminders, send_weekly_report)
from app.models import AuditLog, Family, RosterEntry, Staff
from app.notify import render_email, send_email, send_sms, valid_email
from app.reports import build_monthly, build_weekly, report_filename
from app.routers.admin_people import _qr
from app.routers.kiosk import new_kiosk_token
from app.settings_service import base_url, get_settings, report_recipients
from app.templating import HEX, redirect, render
from app.timeutil import last_sunday_on_or_before, tz, valid_hhmm

router = APIRouter(prefix="/admin", dependencies=[Depends(require_csrf)])
Image.MAX_IMAGE_PIXELS = 25_000_000


@router.get("")
async def dashboard(request: Request, me: Staff = Depends(admin_only), db: AsyncSession = Depends(get_db)):
    s = await get_settings(db)
    d = today(s)
    recs = await day_records(db, d)
    by_class: dict[str, dict] = {}
    for a in recs:
        row = by_class.setdefault(a.class_name, {"in": 0, "pickup": 0, "out": 0})
        row[a.status] += 1
    roster = (await db.execute(select(RosterEntry).options(selectinload(RosterEntry.staff),
                                                           selectinload(RosterEntry.class_group))
                               .where(RosterEntry.service_date == d))).scalars().all()
    fam_count = len((await db.execute(select(Family.id).where(Family.is_active.is_(True)))).all())
    guests = list((await db.execute(select(Family).options(selectinload(Family.children))
                                    .where(Family.is_guest.is_(True)).order_by(Family.created_at.desc())
                                    .limit(10))).scalars())
    sd = await service_day(db, s, d)
    nxt = sd or await next_service_day(db, s, d)
    return await render(request, db, "admin/dashboard.html", {
        "guests": guests, "sd": sd, "nxt": nxt,
        "day": d, "recs": recs, "by_class": by_class, "roster": roster, "fam_count": fam_count,
        "here": len([a for a in recs if a.status != "out"]), "email_ready": config.smtp_configured()})


# ---------------- reports ----------------
@router.get("/reports")
async def reports(request: Request, me: Staff = Depends(admin_only), db: AsyncSession = Depends(get_db)):
    s = await get_settings(db)
    last = last_sunday_on_or_before(today(s))
    sundays = [last - timedelta(weeks=i) for i in range(8)]
    t = today(s)
    months = []
    y, m = t.year, t.month
    for _ in range(6):
        months.append(date(y, m, 1))
        y, m = (y, m - 1) if m > 1 else (y - 1, 12)
    return await render(request, db, "admin/reports.html", {
        "sundays": sundays, "months": months, "recipients": report_recipients(s)})


def _pdf(data: bytes, filename: str) -> Response:
    return Response(data, media_type="application/pdf",
                    headers={"Content-Disposition": f'attachment; filename="{filename}"'})


@router.get("/reports/weekly.pdf")
async def weekly_pdf(request: Request, d: str = "", me: Staff = Depends(admin_only), db: AsyncSession = Depends(get_db)):
    s = await get_settings(db)
    try:
        day = date.fromisoformat(d)
    except ValueError:
        day = last_sunday_on_or_before(today(s))
    log_event(db, actor=me.email, action="report.download", detail=f"weekly {day}", ip=client_ip(request))
    await db.commit()
    return _pdf(await build_weekly(db, s, day), report_filename(s, "weekly", day.isoformat()))


@router.get("/reports/monthly.pdf")
async def monthly_pdf(request: Request, m: str = "", me: Staff = Depends(admin_only), db: AsyncSession = Depends(get_db)):
    s = await get_settings(db)
    try:
        y, mo = (int(x) for x in m.split("-"))
        date(y, mo, 1)
    except ValueError:
        t = today(s)
        y, mo = t.year, t.month
    log_event(db, actor=me.email, action="report.download", detail=f"monthly {y}-{mo:02d}", ip=client_ip(request))
    await db.commit()
    return _pdf(await build_monthly(db, s, y, mo), report_filename(s, "monthly", f"{y}-{mo:02d}"))


@router.post("/send")
async def send_now(request: Request, kind: str = Form(""), d: str = Form(""), m: str = Form(""),
                   me: Staff = Depends(admin_only), db: AsyncSession = Depends(get_db)):
    s = await get_settings(db)
    back = "/admin/reports" if kind in ("weekly", "monthly") else "/admin"
    if kind == "weekly":
        try:
            day = date.fromisoformat(d)
        except ValueError:
            return redirect(back, "Pick a date.", True)
        result = await run_and_log(db, me.email, "manual.weekly_report", send_weekly_report(db, s, day))
    elif kind == "monthly":
        try:
            y, mo = (int(x) for x in m.split("-"))
            date(y, mo, 1)
        except ValueError:
            return redirect(back, "Pick a month.", True)
        result = await run_and_log(db, me.email, "manual.monthly_report", send_monthly_report(db, s, y, mo))
    elif kind == "checkin":
        result = await run_and_log(db, me.email, "manual.checkin_reminder", send_checkin_reminders(db, s))
    elif kind == "checkout":
        result = await run_and_log(db, me.email, "manual.checkout_reminder", send_checkout_reminders(db, s))
    elif kind == "teacher":
        nxt = await next_service_day(db, s, today(s) + timedelta(days=1))
        if not nxt:
            return redirect(back, "No upcoming class day is on the calendar.", True)
        result = await run_and_log(db, me.email, "manual.teacher_reminder", send_teacher_reminders(db, s, nxt.day))
    else:
        return redirect(back)
    return redirect(back, result, result.startswith(("Skipped", "Failed")) or "NOT sent" in result)


# ---------------- settings ----------------
async def _kiosk_link(db: AsyncSession, s) -> str:
    if not s.kiosk_token:
        s.kiosk_token = new_kiosk_token()
        await db.commit()
    return f"{base_url(s)}/checkin/{s.kiosk_token}" if base_url(s) else ""


@router.get("/settings")
async def settings_page(request: Request, me: Staff = Depends(admin_only), db: AsyncSession = Depends(get_db)):
    s = await get_settings(db)
    kiosk = await _kiosk_link(db, s)
    return await render(request, db, "admin/settings.html", {
        "smtp_ok": config.smtp_configured(), "sms_ok": config.sms_configured(), "smtp_from": config.SMTP_FROM,
        "kiosk": kiosk, "kiosk_qr": _qr(kiosk) if kiosk else ""})


@router.post("/settings/kiosk")
async def kiosk_replace(request: Request, me: Staff = Depends(admin_only), db: AsyncSession = Depends(get_db)):
    s = await get_settings(db)
    s.kiosk_token = new_kiosk_token()
    log_event(db, actor=me.email, action="settings.kiosk_link_reset", ip=client_ip(request))
    await db.commit()
    return redirect("/admin/settings#station", "New check-in station link created. The old one stopped working.")


TIME_FIELDS = ("checkin_opens", "checkin_closes", "checkin_reminder_time", "checkout_reminder_time",
               "weekly_report_time", "monthly_report_time", "teacher_reminder_time")
BOOL_FIELDS = ("open_any_day", "require_teacher_release", "checkin_reminder_on", "checkout_reminder_on",
               "weekly_report_on", "monthly_report_on", "teacher_reminder_on", "sms_enabled",
               "email_teachers_on_checkin", "kiosk_guests_on")


@router.post("/settings")
async def settings_save(request: Request, me: Staff = Depends(admin_only), db: AsyncSession = Depends(get_db)):
    s = await get_settings(db)
    f = await request.form()
    errors = []
    s.church_name = str(f.get("church_name", "")).strip()[:120] or s.church_name
    s.program_name = str(f.get("program_name", "")).strip()[:120] or s.program_name
    s.address = str(f.get("address", "")).strip()[:500]
    s.contact_phone = str(f.get("contact_phone", "")).strip()[:40]
    color = str(f.get("brand_color", "")).strip()
    if HEX.match(color):
        s.brand_color = color.upper()
    else:
        errors.append("Brand color must look like #3366FF.")
    url = str(f.get("public_base_url", "")).strip().rstrip("/")[:255]
    if url and not re.match(r"^https://[A-Za-z0-9.-]+(:\d+)?(/[A-Za-z0-9._~/-]*)?$", url):
        errors.append("Web address must start with https:// (for example https://checkin.yourchurch.ca).")
    else:
        s.public_base_url = url
    zone = str(f.get("timezone", "")).strip()
    if tz(zone).key == zone:
        s.timezone = zone
    else:
        errors.append("Unknown time zone. Use a name like America/Toronto.")
    for name in TIME_FIELDS:
        val = str(f.get(name, "")).strip()
        if valid_hhmm(val):
            setattr(s, name, val)
        else:
            errors.append(f"Check the time for {name.replace('_', ' ')}.")
    for name in BOOL_FIELDS:
        setattr(s, name, f.get(name) == "on")
    rec = [e.strip() for e in str(f.get("report_recipients", "")).replace("\n", ",").split(",") if e.strip()]
    bad = [e for e in rec if not valid_email(e)]
    if bad:
        errors.append(f"These report emails don't look right: {', '.join(bad[:3])}")
    else:
        s.report_recipients = ", ".join(rec[:20])
    try:
        s.min_adults_per_class = max(1, min(int(f.get("min_adults_per_class", 2)), 5))
    except ValueError:
        pass
    if s.sms_enabled and not config.sms_configured():
        s.sms_enabled = False
        errors.append("Text messages stay off until Twilio details are added to the .env file.")
    log_event(db, actor=me.email, action="settings.update", ip=client_ip(request))
    await db.commit()
    if errors:
        return redirect("/admin/settings", "Saved, with problems: " + " ".join(errors), True)
    return redirect("/admin/settings", "Settings saved.")


@router.post("/settings/logo")
async def logo_upload(request: Request, logo: UploadFile = File(None), action: str = Form("upload"),
                      me: Staff = Depends(admin_only), db: AsyncSession = Depends(get_db)):
    s = await get_settings(db)
    old = s.logo_file
    if action == "remove":
        s.logo_file = ""
    else:
        if not logo or not logo.filename:
            return redirect("/admin/settings", "Choose a PNG, JPG or WebP image.", True)
        ext = os.path.splitext(logo.filename)[1].lower()
        if ext not in (".png", ".jpg", ".jpeg", ".webp") or logo.content_type not in (
                "image/png", "image/jpeg", "image/webp"):
            return redirect("/admin/settings", "Logo must be a PNG, JPG or WebP image.", True)
        data = await logo.read(config.MAX_LOGO_MB * 1024 * 1024 + 1)
        if len(data) > config.MAX_LOGO_MB * 1024 * 1024:
            return redirect("/admin/settings", f"Logo must be under {config.MAX_LOGO_MB} MB.", True)
        try:
            img = Image.open(io.BytesIO(data))
            img.verify()
            img = Image.open(io.BytesIO(data)).convert("RGBA")  # re-encode: strips metadata and payloads
        except (UnidentifiedImageError, OSError, Image.DecompressionBombError):
            return redirect("/admin/settings", "That file isn't a readable image.", True)
        img.thumbnail((512, 512))
        name = f"logo-{uuid.uuid4().hex[:12]}.png"
        img.save(os.path.join(config.UPLOAD_DIR, name), format="PNG")
        s.logo_file = name
    if old and old != s.logo_file:
        try:
            os.remove(os.path.join(config.UPLOAD_DIR, os.path.basename(old)))
        except OSError:
            pass
    log_event(db, actor=me.email, action="settings.logo", detail=action, ip=client_ip(request))
    await db.commit()
    return redirect("/admin/settings", "Logo removed." if action == "remove" else "Logo updated.")


@router.post("/settings/test")
async def settings_test(request: Request, kind: str = Form(""), to: str = Form(""),
                        me: Staff = Depends(admin_only), db: AsyncSession = Depends(get_db)):
    s = await get_settings(db)
    if kind == "email":
        addr = to.strip() or me.email
        html = render_email("report.html", s=s, title="Test email", body="Email from the check-in app is working.")
        ok = await send_email([addr], f"{s.church_name} check-in: test email", html,
                              "Email from the check-in app is working.", from_name=s.church_name)
        msg = f"Test email sent to {addr}." if ok else "The test email failed. Check SMTP values in .env and the logs."
    elif kind == "sms":
        ok = await send_sms(to, f"{s.church_name}: text messages from the check-in app are working.")
        msg = "Test text sent." if ok else "The test text failed. Check the number and Twilio values in .env."
    else:
        return redirect("/admin/settings")
    log_event(db, actor=me.email, action=f"settings.test_{kind}", detail="ok" if ok else "failed")
    await db.commit()
    return redirect("/admin/settings", msg, not ok)


# ---------------- audit ----------------
@router.get("/audit")
async def audit(request: Request, action: str = "", me: Staff = Depends(admin_only), db: AsyncSession = Depends(get_db)):
    q = select(AuditLog).order_by(AuditLog.created_at.desc()).limit(200)
    action = action.strip()[:40]
    if action:
        q = q.where(AuditLog.action.startswith(action))
    return await render(request, db, "admin/audit.html", {"events": (await db.execute(q)).scalars().all(),
                                                          "action": action})


def _csv_safe(v: str) -> str:
    v = v or ""
    return "'" + v if v[:1] in ("=", "+", "-", "@", "\t", "\r") else v


@router.get("/audit.csv")
async def audit_csv(request: Request, me: Staff = Depends(admin_only), db: AsyncSession = Depends(get_db)):
    rows = (await db.execute(select(AuditLog).order_by(AuditLog.created_at.desc()).limit(10000))).scalars()
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["time_utc", "actor", "action", "target_type", "target_id", "detail", "ip"])
    for e in rows:
        w.writerow([e.created_at.isoformat()] + [_csv_safe(x) for x in
                    (e.actor, e.action, e.target_type, e.target_id, e.detail, e.ip_address)])
    log_event(db, actor=me.email, action="audit.export", ip=client_ip(request))
    await db.commit()
    return Response(buf.getvalue(), media_type="text/csv",
                    headers={"Content-Disposition": 'attachment; filename="audit-log.csv"'})
