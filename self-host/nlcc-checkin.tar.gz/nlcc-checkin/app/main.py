"""App entry point: lifespan, middleware (headers, CSRF seed, session refresh), error handlers, routes."""
import logging
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse, Response
from fastapi.staticfiles import StaticFiles
from sqlalchemy import select
from starlette.exceptions import HTTPException as StarletteHTTPException

from app import config
from app.auth import (CSRF_COOKIE, SESSION_COOKIE, NotAuthenticated, RedirectTo, hash_password, new_csrf_seed,
                      password_problem, set_cookie)
from app.database import async_session, init_db
from app.models import Staff
from app.routers import admin_calendar, admin_ops, admin_people, auth_routes, family, kiosk, profile, teacher
from app.settings_service import get_settings
from app.templating import render

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
logger = logging.getLogger("main")


async def seed_admin() -> None:
    if not config.ADMIN_EMAIL or not config.ADMIN_PASSWORD:
        logger.warning("ADMIN_EMAIL / ADMIN_PASSWORD not set; no admin seeded")
        return
    if password_problem(config.ADMIN_PASSWORD):
        logger.error("ADMIN_PASSWORD must be at least 8 characters; no admin seeded")
        return
    try:
        async with async_session() as db:
            existing = await db.execute(select(Staff).where(Staff.email == config.ADMIN_EMAIL))
            if not existing.scalar_one_or_none():
                db.add(Staff(name="Administrator", email=config.ADMIN_EMAIL, role="admin", can_login=True,
                             password_hash=hash_password(config.ADMIN_PASSWORD)))
                await db.commit()
                logger.info("Seeded admin account %s", config.ADMIN_EMAIL)
            await get_settings(db)
    except Exception as e:  # another worker seeded first
        logger.info("Admin seed skipped: %s", type(e).__name__)


@asynccontextmanager
async def lifespan(_: FastAPI):
    os.makedirs(config.UPLOAD_DIR, exist_ok=True)
    await init_db()
    await seed_admin()
    yield


app = FastAPI(lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)
app.mount("/static", StaticFiles(directory="app/static"), name="static")

CSP = ("default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
       "font-src 'self' https://fonts.gstatic.com; img-src 'self' data:; connect-src 'self'; "
       "form-action 'self'; frame-ancestors 'none'; base-uri 'none'; object-src 'none'")


@app.middleware("http")
async def security_and_session(request: Request, call_next):
    seed = request.cookies.get(CSRF_COOKIE)
    new_seed = None
    if not seed:
        new_seed = new_csrf_seed()
        request.state.csrf_seed = new_seed
    response: Response = await call_next(request)
    h = response.headers
    h["X-Frame-Options"] = "DENY"
    h["X-Content-Type-Options"] = "nosniff"
    h["Referrer-Policy"] = "no-referrer"
    h["Permissions-Policy"] = "camera=(), microphone=(), geolocation=(), payment=()"
    h["Content-Security-Policy"] = CSP
    h["Strict-Transport-Security"] = "max-age=63072000; includeSubDomains"
    h["Cross-Origin-Opener-Policy"] = "same-origin"
    if not request.url.path.startswith(("/static", "/branding")):
        h["Cache-Control"] = "no-store"
    if new_seed:
        set_cookie(response, CSRF_COOKIE, new_seed, 60 * 60 * 24 * 30)
    refreshed = getattr(request.state, "refresh_session", None)
    if refreshed:
        set_cookie(response, SESSION_COOKIE, refreshed, config.SESSION_MAX_AGE)
    return response


@app.exception_handler(NotAuthenticated)
async def not_authenticated(request: Request, _: NotAuthenticated):
    resp = RedirectResponse("/login", status_code=303)
    resp.delete_cookie(SESSION_COOKIE, path="/")
    return resp


@app.exception_handler(RedirectTo)
async def redirect_to(_: Request, exc: RedirectTo):
    return RedirectResponse(exc.url, status_code=303)


@app.exception_handler(StarletteHTTPException)
async def http_error(request: Request, exc: StarletteHTTPException):
    if request.url.path.endswith(".json") or request.headers.get("accept", "").startswith("application/json"):
        return JSONResponse({"error": str(exc.detail)}, status_code=exc.status_code)
    detail = exc.detail if exc.status_code < 500 else "Something went wrong on our side."
    if exc.status_code == 404:
        detail = "This page doesn't exist. If you followed a check-in link, ask the church office for a new one."
    async with async_session() as db:
        return await render(request, db, "error.html", {"code": exc.status_code, "detail": detail},
                            status_code=exc.status_code)


@app.exception_handler(Exception)
async def server_error(request: Request, exc: Exception):
    logger.exception("Unhandled error on %s", request.url.path)
    return await http_error(request, HTTPException(status_code=500))


@app.get("/healthz", include_in_schema=False)
async def healthz():
    return {"ok": True}


@app.get("/branding/logo", include_in_schema=False)
async def logo():
    async with async_session() as db:
        s = await get_settings(db)
    path = os.path.join(config.UPLOAD_DIR, s.logo_file) if s.logo_file else ""
    if not path or not os.path.isfile(path):
        raise HTTPException(status_code=404)
    return FileResponse(path, media_type="image/png", headers={"Cache-Control": "public, max-age=300"})


@app.get("/", include_in_schema=False)
async def home(request: Request):
    async with async_session() as db:
        return await render(request, db, "home.html")


for r in (auth_routes.router, family.router, kiosk.router, teacher.router, admin_people.router,
          admin_calendar.router, admin_ops.router, profile.router):
    app.include_router(r)
