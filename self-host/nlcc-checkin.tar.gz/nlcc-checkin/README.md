# Sunday School Check-in

Check-in and pickup for Sunday school at New Life. Parents use a private family link (no account),
teachers release children with a 4-digit pickup code, and admins get a weekly and monthly PDF
attendance report for the child-safety record.

## Quick start (Ubuntu + Docker)

```bash
tar xzf nlcc-checkin.tar.gz
cd nlcc-checkin
cp .env.example .env
python3 -c "import secrets; print(secrets.token_hex(32))"   # run twice: SECRET_KEY, POSTGRES_PASSWORD
nano .env                                                    # fill in secrets, admin, SMTP
chmod 600 .env
docker compose up -d --build
docker compose ps                                            # app should be "healthy"
```

The app listens on port **4802**. Point the Pangolin resource for
`checkin.newlifetoronto.ca` at `http://<server-ip>:4802` (or `http://app:4802` if Newt
shares the Docker network).

## First sign-in

1. Open https://checkin.newlifetoronto.ca/login and sign in with `ADMIN_EMAIL` / `ADMIN_PASSWORD`.
2. Profile: set up two-step sign-in (optional, recommended for admins). Save the backup codes.
3. Profile > change the password, then blank `ADMIN_PASSWORD` in `.env`.
4. Settings: logo, colors, location, report recipients. Send a test email.
5. Classes: add your classes, open each one and add children (a new family is created as you go).
6. Families: on each family page, press **Email link to guardians**.
7. Calendar: open a day to add teachers, their lesson, and send reminders. Add events (VBS, Christmas program) or cancel a Sunday.
8. Settings > Check-in station link: print the QR code for the foyer or open it on a tablet.

> Login works only over HTTPS while `COOKIE_SECURE=true`. If you test at
> `http://server-ip:4802`, set `COOKIE_SECURE=false` temporarily, then set it back.

## How Sunday works

| Time (Toronto) | What happens |
|---|---|
| Evening before, 6:00 PM | Rostered teachers get a reminder with their class and lesson |
| Sun 9:00 AM | Check-in opens on family links |
| Sun 10:55 AM | Reminder to families not yet checked in (email, optional text) |
| Sun 12:00 PM | Pickup reminder, only to families with a child still checked in |
| Sun 12:30 PM | Weekly PDF report emailed to admins |
| Each check-in | The class's rostered teachers get an email (can be turned off) |
| 1st, 8:00 AM | Monthly PDF report for the previous month |

Calendar events use their own times: check-in opens an hour before the start, parents are reminded
5 minutes before the start and at the end, and the report goes out 30 minutes after the end.
Cancelled days send nothing. All Sunday times and on/off switches are in Admin > Settings. Parents turn their own reminders on or off
from their link ("Reminders and display").

Pickup: the parent taps **Pick up**, chooses who is collecting (guardians plus the approved list),
and gets a code. The teacher enters the code on the class board to release. A teacher can release
without a code (e.g. a dead phone) but it is flagged in the reports.

Check-in station: one shared link (foyer tablet or QR at the door). Parents type 3+ letters of
their child's name; results show first name and last initial only. First-time guests can register
and check in; they appear under "New guests" on the Today page for review. The station never
releases a child.

Deleting a child or family keeps their past attendance in the reports (name only), because the
abuse prevention record must stay complete. A child who is checked in can't be deleted until released.

## Environment variables

| Variable | Required | Default | Purpose |
|---|---|---|---|
| SECRET_KEY | yes | | Signs sessions and family links. Changing it invalidates every family link. |
| POSTGRES_PASSWORD | yes | | Database password (hex) |
| ADMIN_EMAIL / ADMIN_PASSWORD | first run | | Seeds the first admin |
| PUBLIC_BASE_URL | no | https://checkin.newlifetoronto.ca | Default for links in emails |
| TZ_NAME | no | America/Toronto | Default time zone |
| APP_PORT / APP_BIND | no | 4802 / 0.0.0.0 | Host port and bind address |
| COOKIE_SECURE | no | true | Keep true behind HTTPS |
| REQUIRE_ADMIN_MFA | no | false | true forces two-step sign-in for admins |
| SMTP_* | for email | | Mail server for reminders and reports |
| TWILIO_* | no | | Enables optional text messages |

## Operations

```bash
docker compose logs -f app scheduler        # watch
docker compose pull db && docker compose up -d --build   # update
# Backup (run nightly from cron; keep copies off this server)
docker compose exec -T db pg_dump -U checkin checkin | gzip > checkin-$(date +%F).sql.gz
# Restore
gunzip -c checkin-YYYY-MM-DD.sql.gz | docker compose exec -T db psql -U checkin checkin
```

Firewall: only Pangolin/Newt needs port 4802. With ufw, for example:
`sudo ufw allow from <newt-ip> to any port 4802 proto tcp`.
Note that Docker-published ports bypass ufw's default rules; use `APP_BIND=127.0.0.1`
when Newt runs on the host, or keep Newt on the Docker network.

Lost a family link or it was shared: open the family in Admin and press **Replace link**.
Locked out admin: another admin can unlock or reset two-step sign-in under Staff.

## Architecture

```
Parent phone ──HTTPS──▶ Pangolin ──▶ app (FastAPI, :4802) ──▶ PostgreSQL (internal only)
                                       scheduler (same image) ─┘   └─▶ SMTP / Twilio
```

Security: bcrypt (cost 12) passwords, TOTP two-step for admins, account lockout after 5 failures,
signed HttpOnly cookies, CSRF on every form, strict CSP (no inline scripts), rate limiting,
non-root read-only containers, audit log of every check-in, release, sign-in and settings change.
